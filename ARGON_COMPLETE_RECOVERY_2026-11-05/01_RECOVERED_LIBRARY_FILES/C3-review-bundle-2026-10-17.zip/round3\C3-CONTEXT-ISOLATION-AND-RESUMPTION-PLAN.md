# C3 — CONTEXT ISOLATION AND STALE-STATE RESUMPTION EXPERIMENT PLAN (RECONCILED CANDIDATE r3)

```yaml
artifact_kind: experiment_plan
candidate_revision: r3-reconciliation-2026-10-15
supersedes_candidate: r2-candidate-2026-10-14 (staging only; never accepted)
cloud: C3
wave: cloud-evolution-sprint
system_scope: ai_engineering_os
repository_target: none
execution_target: deliverable_output
status: DESIGNED
implementation_status: NOT_IMPLEMENTED
test_status: TEST SPECIFIED
tests_executed: 0
experiment_status_all: TEST SPECIFIED (nothing executed)
benchmarks_run: 0
c7_report_reconciled: assurance/audits/C7-FFA-003.md (sha256 6ad46d60c08c71804e5efc3081f13ab0dbd53d83860c5924e888e26ffe0ccba7)
date: 2026-10-15
baseline_ai_os_main_sha: 71a3fa6d1fb1eed0e694886263710d4020e10341
source_container:
  file: c2-c6(1).TXT
  sha256: a542be977e7af20dfe90be08585b1a05e094351805a0d8c9dcb22301b2d0039a
  assigned_line_range: 567-968
  raw_extraction: NOT_PERFORMED   # the TXT was not supplied to this session; see §0.1 and the provenance note
prior_draft_basis: prior-draft/C3-CONTEXT-ISOLATION-AND-RESUMPTION-PLAN.prior-draft-2026-10-13.md  # my own earlier draft; NOT proven identical to TXT lines 567-968
report_sha256: recorded_in_manifest   # hash contract: real SHA-256 of these exact bytes lives only in the companion manifest
```

**Nature.** Design and test specification only. Nothing here implements the context engine, a checkpoint mechanism, a memory service or isolation code, and none exists (`STATUS.md`: `NOT_IMPLEMENTED`; `docs/CURRENT-STATE.md`: no test execution has occurred). **No case in this document has been executed; none is marked passed.** Where a numeric value would be needed it is labelled `THRESHOLD NOT SET` with the experiment that would set it.

**Reconciliation pass (2026-10-15).** `main` was re-checked and is unchanged at `71a3fa6d…`; the intake branch tip is an ancestor of `main`; no accepted C3 output exists on `main` (there is no `assurance/experiments/` directory). §0.3 now separates **canonical**, **supporting**, **historical**, **absent** and **staging-candidate** artifacts, and §0.4 flags which Wave 3.5 sources are *historical*, not canonical. §3.0 adds an explicit scenario catalogue; §7.3 adds a TEST SPECIFIED / TEST EXECUTED ledger. The claim-to-source map with exact line ranges is `maps/C3-SOURCE-TO-CLAIM-MAP.md`.

**What r2 corrected.** The prior draft (2026-10-13) was written in an isolated session that held only uploaded files. It declared C1, the C5 pack v2, the C2/C4 packs, `OPEN-QUESTIONS.md`, `DEPENDENCY-REGISTER.md`, `NEXT-ACTIONS.md` and the Wave 3.5 schemas "not available." That was true of that session, **not of AI-OS `main`**. §0 replaces those statements with what was found on `main` at `71a3fa6d…` and what is still genuinely absent. See `C3-SOURCE-TRACEABILITY-AND-CORRECTION-LOG.md` for the line-by-line change list.

---

## 0. Baseline Record, Revalidation and Corrected Inventory

### 0.1 Provenance and extraction status (stated plainly)

| Item | State |
|---|---|
| Assignment | "Review TXT lines 567–968" of `c2-c6(1).TXT`, SHA-256 `a542be977e7af20dfe90be08585b1a05e094351805a0d8c9dcb22301b2d0039a` (from the prompt pack) |
| TXT supplied to this session | **No.** Only the prompt pack was uploaded. |
| Raw extraction of lines 567–968 | **NOT PERFORMED. Cannot be claimed.** No byte-preserving copy of that range exists in the staging directory. |
| What this candidate is built on | My own earlier draft (SHA-256 recorded in the manifest), which I believe corresponds to that TXT range but **cannot verify**. It is preserved untouched in `prior-draft/` as the diff baseline, **not** as the raw extraction. |
| Consequence | "Changes vs raw extraction" cannot be reported. Changes vs the prior draft are reported. Whoever holds the TXT must run the extraction (command in the provenance note) and compare. |

### 0.2 Repository baseline

| Item | Value |
|---|---|
| GitHub `main` SHA verified this run (`git ls-remote`) | `71a3fa6d1fb1eed0e694886263710d4020e10341` (matches the pack's baseline) |
| Local working copy | read-only blobless sparse clone under the staging directory, branch `main`, HEAD `71a3fa6d…`, working tree clean; `archive/external-health/` deliberately not checked out |
| Writes to the repository | none: no commit, push, branch, PR, or edit of any tracked file |
| Input hashes | `logs/input-hashes.txt`, also reproduced in the manifest |

### 0.3 Artifact classes and inventory (what exists, and in what standing)

**Class definitions** (taken from `STATUS.md` §2 vocabulary and `docs/CURRENT-STATE.md`; nothing new is invented):

| Class | Meaning | Test applied |
|---|---|---|
| **CANONICAL** | On `main`, `STATUS.md` status `CANONICAL`, hash listed in `STATUS.md` §3 and matching | `sha256sum` equals the table value |
| **CURRENT_SUPPORTING** | On `main`, `STATUS.md` status `CURRENT_SUPPORTING` (future capability packs); `DESIGNED`, not canonical research | Present on `main` |
| **HISTORICAL** | On `main` under `archive/historical/`; preserved record, **not** current canon | Path |
| **DUPLICATE / SUPERSEDED** | `archive/duplicates/`, `archive/superseded/` | Path |
| **ABSENT** | Named by a register or another artifact but not in the tree | Tree listing + keyword search |
| **STAGING CANDIDATE** | Exists only in the isolated staging directory; not on `main` | Path outside the repo |
| **ACCEPTED OUTPUT** | A staging candidate that has been merged to `main` and listed in `STATUS.md` / the index | None exists for this plan |

| Artifact | Class | Path / state | Verification and read extent |
|---|---|---|---|
| C1 Harness research | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | SHA `24e8cdb1…688f` = `STATUS.md` §3. Sections and keyword reads; not whole-file |
| C2 research | CANONICAL | `clouds/C2/…RESEARCH.md` | SHA `c6e95c26…0b99` match; read whole earlier |
| C3 research | CANONICAL | `clouds/C3/…RESEARCH.md` | SHA `b48cbb0b…042c` match; read whole earlier |
| C4 protocol | CANONICAL | `clouds/C4/…PROTOCOL.md` | SHA `441007bc…1651` match; read whole earlier |
| C5 research | CANONICAL | `clouds/C5/…RESEARCH.md` | SHA `e70ea36b…e1a8` match; read whole earlier |
| C6 evaluation | CANONICAL | `clouds/C6/…ENGINE.md` | SHA `a0d762ad…946a` match; zero checkpoint/resume hits |
| C2, C3, C4, C5-v2 future packs | CURRENT_SUPPORTING (`DESIGNED`) | `capabilities/future/C{2,3,4,5}/…` | C3 pack = `bb0568be…83cf` (identical to my r3 pack; self-authored, **not independent evidence**); C5 v2 = its own `report_sha256` `744a1c62…bff0`; C2/C4/C5 read by section and keyword |
| C7 audit | CANONICAL (`STATUS.md` row) | `assurance/audits/C7-FFA-003.md` | SHA `6ad46d60…ccba7`; verdict `CLEAN WITH OPEN EXPERIMENTS`; Gates 3, 4, 9 and open list re-read |
| `STATUS.md`, `OPEN-QUESTIONS`, `DEPENDENCY-REGISTER`, `NEXT-ACTIONS`, `capability-index` | Registers (shared; not edited) | repo root / `planning/` / `capabilities/` | Read in full |
| Wave 3.5 set (C1 Correction v2, C2 Reconciliation v2, C3 Knowledge v2, C5 Operator v2, C6 Verification Master, + manifests) | **HISTORICAL** | `archive/historical/wave3.5/` | Section and keyword reads |
| Earlier C3 research copy, C7 final-forensic file | DUPLICATE | `archive/duplicates/` | Not used as evidence |
| C1 Cross-Cloud Synthesis v2 | **ABSENT** | would be `…SYNTHESIS.v2.md` | `STATUS.md` §4.1, DEP-03 |
| C6 future capability pack | **ABSENT** | would be `capabilities/future/C6/…` | `STATUS.md` §4.2, DEP-07 |
| Wave 3.5 Convergence Patch v3 | **ABSENT** | cited by C1 research | §0.4 |
| C3 Wave 3.5 v1 knowledge model; Wave 3.5 C4 context `.md` | **ABSENT** | — | §0.4; `STATUS.md` §4.3 |
| `assurance/experiments/C3-CONTEXT-ISOLATION-AND-RESUMPTION-PLAN.md` on `main` | **ABSENT** (no accepted output) | `assurance/experiments/` does not exist on `main` | tree listing at `71a3fa6d` |
| This plan (r2, r3), manifest, maps, logs | **STAGING CANDIDATE** | staging directory only | hashes in the manifest |
| Prior draft 2026-10-13 | STAGING (superseded, retained as diff baseline) | `prior-draft/` | not proven equal to TXT lines 567–968 |

**Why the class matters.** Several claims in earlier drafts rested on the historical Wave 3.5 files as if they were current design. They are a recorded design pass, not canon. Where the canonical C3 research says `UNKNOWN` and a historical file proposes a rule, **both** are reported and the rule is treated as a proposal (§0.4, §2.2).

### 0.4 Wave 3.5 schema search (result, not assumption)

Searched `archive/historical/wave3.5/*.md` and the repo-wide text for each object and for any convergence patch. **All "Found" rows below are HISTORICAL-class sources** (`archive/historical/wave3.5/`), except where a canonical file is named. The canonical C3 research (§1 Context Projection vs Packet; §3 isolation `NEEDS EXPERIMENT`; §4 freshness) is the controlling statement, and it is **more cautious** than the historical files: canonical §4 says "when must re-fetch happen? UNKNOWN / NEEDS EXPERIMENT," while historical C1 Correction §7 lists four triggers. This plan treats the historical triggers as proposals under test, not as settled design.

**Found (schema definitions that exist in the repository):**

| Object | Where defined | What it gives this plan |
|---|---|---|
| Context Projection vs Context Packet split | `C1-WAVE3.5-CORRECTION-v2.md` §2; `C3-WAVE3.5-KNOWLEDGE-v2.md` §2 | Projection = versioned rule `(projection_id, version)`; Packet = immutable instance with `projection_id`, `projection_version`, `token_tier`, `files` (C1 §2) or keyed `(task_packet_id, for_cloud, repo_snapshot_id)` (C3 §2). **The two files name Packet fields differently; unreconciled.** C3 v2 status: `DESIGNED`, **requires C1 ratification**. |
| Staleness of a Packet by projection version | C1 Correction §2 | A Packet whose `projection_version` is behind the current version "is flagged for regeneration." → SL-09 / SC-15. |
| Task-context isolation default | C1 Correction §6 | New `task_id`; built from Kernel + live Repository Snapshot + own routing; **never inherits prior Packets/Claims/Evidence by copy**; only linkage is an explicit `references_task_id`, user-requested or recorded as a `Dependency` by C1. → SC-01, SC-07, SC-11 oracle. |
| Staleness triggers | C1 Correction §7 | Four triggers (mandatory re-check at PLAN for ADR/ACR/domain questions; age threshold; contradiction with a prior Handoff Record; user-stated change). **Trigger 2's "15 minutes" is explicitly "a judgment call, not evidence-derived; flagged for human confirmation."** → **not adopted here; freshness window stays unset.** |
| Repository Snapshot | C3 Knowledge v2 §1; C6 Verification Master §1.3 | Fields `remote_url, branch, head, origin_head, clean, shallow` (nullable when no git repo); C6 adds repo target, timestamp; write-once. |
| Claim → Evidence Record → Source → Verification Record chain | C3 Knowledge v2 §5 (H) | Evidence is **inert** unless its Source is `resolvable`, checked at/after `gathered_at`; Verification methods `chain_resolution_check` (necessary, not sufficient) and content review recorded separately. → SC-14. |
| Referential integrity rules | C3 Knowledge v2 §7 | → SC-14 oracle. |
| `Handoff Record` / `Cloud Result` | C3 Knowledge v2 §3; C1 Correction §3 | **Name reserved.** Both files say one canonical "Handoff Record." **They disagree on the producer** (C3 v2: C1 only, once per wave; C1 Correction: promoted by the specialist Cloud from a validated Cloud Result). See §1.1 naming consequence. |
| Approval Record | C3 Knowledge v2 §6; C1 Correction §5 | **Two differing field lists** (C3: `repo_snapshot_id`, `valid_until`, `decision`; C1: `approved_plan_ref`, `scope`, `approver=human`). Schema owner C3; hard-gate enforcement C2; pipeline placement C1. Enforcement is out of this plan's scope. |
| Three-field target model | C1 Correction §1; C7 Gate 4 | `system_scope`, `repository_target`, `execution_target` (superseding C3 v2's three-value `repo_target` enum). Used in this plan's fixtures. |
| Status axes (`processing_state`, `lifecycle_status`, `evidence_class`, `claim_status`) | C3 Knowledge v2 §4 | Vocabulary reused. |

**Not found (true gaps, each with evidence of the search):**

| Missing item | Evidence it is missing | Effect on this plan |
|---|---|---|
| **Wave 3.5 Convergence Patch v3** | Cited by `C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` L202, L223, L355–L361, L517 (Approval Record **content-hash binding**, §4; `task_id`; status vocabulary). No file of that name or content in the repo tree, `evidence/MANIFEST.json`, or `evidence/source_moves_registry.json`. | **True missing convergence patch.** Hash-binding semantics are not defined here and are not assumed. Cases that would touch them are marked as dependent. |
| `C3-WAVE3.5-AI-OS-KNOWLEDGE-MODEL.md` (v1; SHA `32114b7…4e24333b7` per v2 header) | C3 Knowledge v2 §9 says Task Packet, Dependency, Claim, Source, Evidence Record, Cloud Result, Decision Reference "carried forward as-is — see prior artifact"; v1 is absent from the repo. | **Full field lists for Task Packet, Dependency, Claim, Source, Evidence Record, Cloud Result, Decision Reference are not in the repository.** This plan uses only the field names that appear in the files listed above and treats the rest as `UNKNOWN`. |
| Wave 3.5 C4 Context markdown | `STATUS.md` §4.3 | Only its manifest exists. Nothing is inferred from it. |
| Checkpoint-reference field on the Approval Record | C1 research L221: "open schema gap" | Checkpoint reference is not a defined schema field anywhere. |
| Checkpoint invalidation rule; stale-state resumption mechanism | C1 research L222, L224, L495; `OPEN-QUESTIONS` OQ-06 | Undesigned. The cases below are tests of requirements, not of a design. |
| Context Packet field reconciliation (C1 vs C3 key names), Approval field reconciliation | see table above | Both unresolved; no field is picked here. |

### 0.5 Registers and status (current, not assumed)

- **OQ-06** *Context Stale-State Resumption & Compaction* (origin: C3 §3, C1 checkpoint resumption): `NEEDS EXPERIMENT`. This plan **specifies tests toward OQ-06; it does not close it.**
- `STATUS.md`: C3 Context Engine `CANONICAL`, `NOT_IMPLEMENTED`, `TEST SPECIFIED`, "Benchmark threshold validation needed."
- DEP-03 (C1 Synthesis v2) `BLOCKED / PENDING C1`; DEP-07 (C6 packs) `MISSING`; DEP-06 (C6 evaluation harness) `DESIGNED`. No dependency row covers this plan's own prerequisites (proposed in §8.3 as text only).
- **C7 reconciliation.** C7-FFA-003 (2026-10-07 per its own text; `STATUS.md` verification date 2026-10-12) verifies hashes (Gate 1), spot-checks C1 (Gate 3) and cross-Cloud consistency (Gate 4). It does **not** audit this plan, C3's isolation design or any resumption design; it lists them as open. Nothing here is "C7-confirmed." No C7 report newer than FFA-003 exists on `main` (`NEXT-ACTIONS` ACTION-03 plans FFA-004 for the Synthesis).
- C7-FFA-003: "task-context isolation (C3 §3)" and "checkpoint stale-state resumption" remain open and "genuinely require a real implementation environment that does not exist yet."

### 0.6 Existing proposals and experiments this plan builds on (not duplicated)

| Existing item | Source | Relation to this plan |
|---|---|---|
| **E3** stale detection (`head` vs `origin_head`) | C3 research | Extended by group B / §2.2 |
| **E4** isolation (two adversarial concurrent tasks; zero leakage; **N undetermined**) | C3 research (~L285, L402) | Operationalized by group A. "Zero leakage" is source-defined; **N stays unset.** |
| **E5** compression loss; **E6** evidence preservation | C3 research | SC-08; SC-14 |
| **P15 pre-experiment** (is compression needed at real session lengths) | C3 research | Gates SC-08 cost claims; **not run** |
| C1 Pattern 5 / **E4 checkpoint-linked approval** | C1 research | Defines "checkpoint" as the **Repository Snapshot at approval, not the Cloud's conversational context** (L219). This plan's "context snapshot" goes beyond that; see §1 divergence note. |
| C5 E5 (no duplicate side effect on resume), E8 (stale display), P8 (unattended fail-closed), P10 (resume from structured state; state-only vs audit-preserving resume `UNKNOWN`) | C5 research; C5 packs v2 Pack 5 | Informs SC-06, SC-13 and definitions; flow ownership stays C5 |
| C4 Pack 001 (control-plane journal referencing `approval_ref`, `snapshot_ref`, …) | C4 packs §4.1 | **Not tested here.** It is C4's proposal; this plan states only what C3 must supply (`external_effects[]` semantics). |
| `false_completion` canary, Grounding, Evidence integrity (target 0, definitional), Token-efficiency; "compression applies only to active context, never the durable record" | C6 research | Metrics and rules reused, not redefined |
| T0–T5 tiering (**proposed, unverified**; C1 Correction §2 shows a `token_tier` field on Context Packet) | C6 note; C3 P2; C1 Correction §2 | Not defined here; **no ceilings.** |
| CTX-001/002/003/004 | `capabilities/future/C3/…` (canonical, identical to my r3) | Treated as hypotheses under test |

### 0.7 Evidence labels

**[V]** verified observation from an inspected artifact · **[S]** strongly supported inference · **[P]** proposal requiring an experiment · **[U]** unknown or unavailable. Terminology marked **(PROPOSED)** is introduced by this document and is not canonical.

---

## 1. Definitions

Terms below are **PROPOSED terminology**. Wave 3.5 objects are now sourced from the repository (§0.4), but their field lists are incomplete there, so mappings stay labelled `UNKNOWN` where a field list is absent.

**Name-clash warnings.**
1. "Repository Snapshot" (write-once; `head`/`origin_head`) and "Context Packet" (immutable instance) exist. Nothing below renames them.
2. **`Handoff Record` is a reserved Wave 3.5 name** (C3 Knowledge v2 §3 invariant: any "handoff" means `Handoff Record` and only that). The prior draft's "handoff record" therefore collided with it and is **renamed "resumption record"** in this candidate. Whether a resumption record is a field set of a Handoff Record, of a Cloud Result, or a separate object is **UNKNOWN**, and the two Wave 3.5 files disagree on who produces a Handoff Record (§0.4). No choice is made.

| Term | Definition (PROPOSED) | Relation to existing objects |
|---|---|---|
| **Context snapshot** | The immutable record of what one task's context was when generated: item ids with versions, scope and origin labels, protected-span list, and a **freshness manifest** (ids/versions of the Repository Snapshot, Context Projection, Task Packet it was built from). Ids, versions, counts only — no source bodies, no secrets. | Likely the freshness/lineage view of a Context Packet (which already carries `projection_id`/`projection_version`). Whether it is a field set of the Packet or a separate record is **UNKNOWN**. |
| **Checkpoint reference** | A pointer to (a) one context snapshot and (b) one resumption record. A reference, not a copy of context and not a transcript. | **Divergence to flag:** C1 research L219 defines what is checkpointed as the **Repository Snapshot at approval, explicitly not the Cloud's conversational context**. A pointer to a *context snapshot* extends that and needs C1 ratification. **Ownership of the checkpoint object is OPEN (§6.2).** |
| **Resumed context** | Context regenerated after an interruption by re-validating the snapshot's references, regenerating what is regenerable from sources, and emitting a **reconstruction diff**. Each item carries `UNCHANGED`, `CHANGED`, `MISSING`, `CORRUPTED` or `UNVERIFIED`. | Per C5 P10, resume basis is structured state, not a reasoning transcript. C5 leaves "state-only vs audit-preserving resume" `UNKNOWN`; this plan does not decide it. |

### 1.1 Resumption record (PROPOSED minimum contents; formerly "handoff record")

| Field | Content |
|---|---|
| `completed[]` | Work items **verified** complete, each with an evidence reference |
| `partial[]` | Items begun but unverified, with what exists and what is missing |
| `not_started[]` | Remaining items |
| `unknown[]` | Items whose state cannot be established from recorded evidence |
| `source_provenance[]` | Item ids, versions, origin and scope labels |
| `current_state` | State markers at checkpoint time |
| `blockers[]` | Unresolved blockers and what they wait on |
| `external_effects[]` | Each external effect with `COMPLETED_WITH_EVIDENCE`, `UNKNOWN` or `NOT_ATTEMPTED`; plus a `do_not_repeat_without_confirmation[]` list derived from it |
| `constraints[]` | Protected spans (hard constraints, limits, hedges) |
| `open_questions[]` | Unresolved questions |

C3 owns the **context semantics** of these fields. Whether and how an external effect may be re-attempted is **C4's** decision; who may be authorized to resume is **C2's**; how pause/resume is presented to an operator is **C5's** (§6).

### 1.2 File identity, source freshness, semantic correctness

Three different questions; tests keep them separate and a result for one is never reported as a result for another.

| Question | Meaning | Candidate signal | What it can establish |
|---|---|---|---|
| **File identity** | Same object the snapshot referred to? | Stable id, path, content hash | Same / moved / replaced / missing |
| **Source freshness** | Has content or version changed since the snapshot? | Version id, content hash, repository `head` vs `origin_head` | Changed / unchanged |
| **Semantic correctness** | Is a claim citing this source still *true*? | Verification Record, independent check, dependency links | Only a verification step can say; **freshness cannot** |

Rule under test: an `UNCHANGED` freshness result **never** implies a dependent claim is correct. Mtime/touch is a metadata signal, not a content-change signal (policy is open, §5).

---

## 2. Fixtures, Staleness Conditions and Oracles

All fixtures are **synthetic**, invented for this plan, with no ARGON or ARGON-HEALTH content, no real credentials, no personal or patient data. They are designed once, hashed, frozen; every run records the fixture hash. **A fixture is frozen at its hash; a change creates a new fixture id (§7.4).**

| Fixture | Description |
|---|---|
| **FX-REPO-1** | Tiny synthetic git repository of 12 short documents `DOC-01…DOC-12` about a fictional product "Project Lumen." `head` can be advanced deterministically. A bare "remote" in the same fixture provides `origin_head`. |
| **FX-CLAIMS** | `DOC-03` states "retry limit = 3"; `DOC-07` states "retry limit = 5" (a *fixture-internal* conflict; no retry value is a recommendation or guarantee). `DOC-05` is a shared immutable source cited by both tasks. `DOC-04` depends on `DOC-11`. |
| **FX-TASKS** | Task **X** (scope `SX`) and task **Y** (scope `SY`), each a short question task over FX-REPO-1, plus a five-step work task `W1…W5`. Each carries the three-field target model (`system_scope`, `repository_target`, `execution_target`) fixed in the fixture. |
| **FX-CANARY** | Unique non-sensitive markers per task (`CNRY-X-0001`, `CNRY-Y-0001`), per-task decision records (`D-X-1: "assumes retry limit 3"`), and a secret-**shaped**, obviously fake token (`FAKE-SECRET-NOT-REAL-0001`). |
| **FX-CONSTRAINTS** | Protected spans: `C-01` ("MUST NOT write to path P-FIXTURE-PROTECTED," at start), `C-02` ("limit is 40 items," middle), `C-03` (a negation, end), `H-01` ("approximately 40, unconfirmed"). |
| **FX-SESSION** | Long synthetic session log with low-priority chatter around FX-CONSTRAINTS. **Length NOT SET**; must come from P15. |
| **FX-EVIDENCE-1** | A synthetic Claim→Evidence Record→Source→Verification Record chain set: sources `resolvable`, `unresolvable`, `not_yet_checked`; chain-resolution-only and content-review Verification Records; one Claim self-certified by its producing Cloud (negative case). Field names limited to those in §0.4. |
| **FX-SINK-1** | Local append-only stub recording attempts (`run_id`, `effect_id`, timestamp). Implements **no** idempotency or protection (that is C4's). |
| **FX-POLICY-STUB** | Scripted allow/deny source standing in for C2's decision (`deny`, `allow+Dependency`, `no_decision`). Defines no authorization or trust semantics. |
| **FX-CHECKPOINTS** | `CP-1…CP-4` snapshot/resumption record sets, including damaged variants (truncated, missing manifest, wrong schema version, missing protected-span list, dangling reference). |
| **FX-INTERRUPT** | A harness-agnostic way to stop a task at points `P1…P5` (before first read; mid-retrieval; packet built, not yet used; after partial output; just after an external effect) for each trigger class: rate limit, timeout, context compaction, operator pause, killed session. |
| **Dev / held-out split** | **Development set** for tuning; **held-out set** only for claiming results (C3 P10; C6 Pattern 2). Sizes **NOT SET**. |

### 2.1 Proposed observable log events (all PROPOSED)

Events carry ids, versions, hashes, counts, outcomes — **never content bodies**.

`SNAPSHOT_CREATED`, `FRESHNESS_CHECKED{item,old_version,new_version,result,checked_by,checked_at}`, `ISOLATION_FILTERED{counts_by_reason}`, `POLICY_DECISION_CONSULTED{mode}`, `ACCESS_RESULT{requester,item_class,outcome}`, `COMPONENT_VALIDATED{component,result}`, `RECONSTRUCTION_STARTED/COMPLETED`, `DIFF_EMITTED`, `RESUMPTION_RECORD_WRITTEN`, `COMPACTION_PERFORMED{trigger}`, `PROTECTED_SPAN_CHECK{detected,present,fallbacks}`, `SOURCE_READ{item,reason}`, `CHAIN_CHECKED{claim,evidence,source_status,result}`, `PROJECTION_VERSION_CHECKED{packet,packet_version,current_version,result}`, `EXTERNAL_EFFECT_ATTEMPT_OBSERVED{effect,run}` (from FX-SINK-1 only).

### 2.2 Controlled staleness conditions

Each condition is induced **deterministically on a frozen fixture** by the harness, not by waiting. "Source basis" says where the requirement comes from; nothing is invented. Detection **rates** are measured (M3); no rate bar is set except where a source sets one.

| ID | Condition (induced by) | Expected signal (oracle in §2.3) | Source basis (H = historical class) | Bar |
|---|---|---|---|---|
| SL-01 | `origin_head` advances past the snapshot's `head` (new commit on the fixture remote) | Detected as stale | C3 E3; C1 Corr. §7 (H) | C3 E3's own 100%/0% applies to this check only |
| SL-02 | Freshness source unreachable (remote made unreadable) | `UNVERIFIED`, never `FRESH` | CTX-001; C5 P8 | fail-closed requirement; no rate |
| SL-03 | Cited document content edited | `CHANGED`; dependent claims flagged for re-verification | C3 E6; CTX-001 | — |
| SL-04 | Touch-only (mtime changed, bytes identical) | Reported as metadata signal, not content change | open decision §5 | **THRESHOLD NOT SET** |
| SL-05 | Whitespace-only edit | `CHANGED`; semantic re-check flagged | — | **NOT SET** |
| SL-06 | Same bytes moved to a new path | Candidate relocation requiring confirmation; not silently re-bound | open decision §5 | **NOT SET** |
| SL-07 | Cited document deleted | `MISSING`; reference preserved; dependents `UNVERIFIED` | C3 E6 | — |
| SL-08 | Upstream document (`DOC-11`) revised so unchanged `DOC-04`'s claim becomes wrong | Freshness `UNCHANGED` **and** "freshness ≠ correctness" recorded; detected only via a recorded dependency link, otherwise a documented expected miss | C3 §3 Dependency; §1.2 | — |
| SL-09 | Context Projection advances to a new version after a Packet was built | Packet flagged for regeneration | C1 Corr. §2 (H) | — |
| SL-10 | A later Cloud claim contradicts a recorded Handoff Record citing the same repository | Re-check performed **before** escalating as a contradiction | C1 Corr. §7 (H) trigger 3 | — |
| SL-11 | Operator states in-conversation that the repository changed | Immediate unconditional re-check | C1 Corr. §7 (H) trigger 4 | — |
| SL-12 | Evidence Record's Source becomes `unresolvable` after first citation | Evidence **inert**; Claim cannot advance past `asserted` | C3 Knowledge v2 §5 (H) | — |
| SL-13 | Approval-time `repo_snapshot_id` no longer matches the current Repository Snapshot | **C3-side only:** drift is detected and reported. Whether execution is blocked is C2/C4 (Approval invariant, C3 v2 §6) | C3 Knowledge v2 §6 | enforcement out of scope |
| SL-14 | **Age-based** staleness (elapsed time only) | **Not specified.** C1 Corr. §7 (H) trigger 2's 15-minute value is flagged by its own author as not evidence-derived; no window is adopted. The case becomes specifiable only after a decision. | C1 Corr. §7 (H) | **FRESHNESS WINDOW NOT SET** |
| SL-15 | Mandatory re-check at PLAN when risk touches an ADR/ACR/domain-authority question | Live check occurs regardless of snapshot age | C1 Corr. §7 (H) trigger 1 | — |

### 2.3 Independent oracles

An oracle is **independent** only if it does not share a code path or data path with the component being tested. **The engine's own report (its freshness result, its isolation filter, its handoff text) is the thing under test and is never its own oracle.**

| Oracle | Computed by | Used for | Independence note |
|---|---|---|---|
| **O1 Ground-truth table** | Authored before any run, hashed with the fixture (expected status per item per condition) | all cases | Fixed in advance; cannot be adjusted after seeing output |
| **O2 Git facts** | Plain `git rev-parse`, `git diff --name-status`, `git hash-object` run by the harness on FX-REPO-1 | SL-01, 03, 05–07 | Independent of any ARGON component |
| **O3 Canary scan** | Raw string search over packets, outputs, caches, logs, written by the harness | M1 | Does not use the isolation filter's own accounting |
| **O4 Sink count** | FX-SINK-1 append-only file | M5, SC-06 | Counts attempts at the sink, not the engine's claims |
| **O5 Durable-store hash** | SHA-256 of the durable record before and after | SC-08 | — |
| **O6 Referential/chain checker** | A separate checker implementing only the rules in C3 Knowledge v2 §5 and §7 | SC-14 | Must not be the validator under test |
| **O7 Human labels** | Human-assigned ground truth for semantic correctness (SC-09 v/vi) and blind-resume grading | M4, M7 | Only a human or an independent verification step can assess semantic truth; labels recorded before runs |
| **O8 Policy script** | The FX-POLICY-STUB scenario table | SC-07 | Defines no policy; scenario only |

---

## 3. Scenario Catalogue and Test Cases

### 3.0 Scenario catalogue (explicit scenarios; each maps to detailed cases below)

A scenario states the situation and the **safe expected behavior** as a hypothesis. It is not a result. Detailed setup, steps, failure conditions and evidence are in the referenced `SC-` case. Every scenario is `TEST SPECIFIED`; none executed.

| ID | Given | When | Then (expected, hypothesis) | Safe-failure rule | Cases |
|---|---|---|---|---|---|
| **SCN-ISO-01** | Tasks X and Y with conflicting fixture claims (3 vs 5) | Both run, any ordering | Each packet holds only its own private items; shared `DOC-05` by reference with label | Any cross-task item = leak; conflicts not merged silently | SC-01 |
| **SCN-ISO-02** | Y asks for X's private item by query, id, cache, lineage | Policy stub: `deny` / `allow+Dependency` / `no_decision` | Deny: nothing returned, indistinguishable from "absent"; allow: served with label | No decision = deny | SC-07 |
| **SCN-ISO-03** | X wrote a derived summary and a mixed derived item exists | Y runs later | Cache keys include scope; mixed item takes the strictest scope | Scope label never stripped by a transform | SC-11 |
| **SCN-ISO-04** | Two resumers of one checkpoint reference | Resume concurrently | Independent, equivalent contexts; no cross-contamination | Who may proceed is undefined (not tested) | SC-16 |
| **SCN-STL-01** | Snapshot at `head` R0 | `origin_head` advances | Stale detected (C3 E3 bar applies to this check only) | Undeterminable ⇒ `UNVERIFIED`, never `FRESH` | SC-02, SL-01, SL-02 |
| **SCN-STL-02** | Checkpoint cites `DOC-03`, `DOC-09` | Edited / moved / deleted | `CHANGED` / candidate relocation / `MISSING`; reference preserved | Dependents `UNVERIFIED`, never silently kept verified | SC-02, SC-05 |
| **SCN-STL-03** | Touch-only, whitespace-only, upstream revision, wrong-from-start claim | Resume | Identity, freshness, correctness reported separately; freshness never equals correctness | Expected misses documented, not hidden | SC-09 |
| **SCN-STL-04** | Packet built under Projection v1 | Projection advances | Packet flagged for regeneration, not reused as current | Old Packet retained, never edited | SC-15 |
| **SCN-INT-01** | Task interrupted at `P1…P5` by rate limit, timeout, compaction, operator pause, kill | Resume each | Resumed context equivalent regardless of trigger for equal recorded state | Mislabeled item state = failure | SC-10 |
| **SCN-INT-02** | External effect at the sink; interruption around it | Resume | `COMPLETED_WITH_EVIDENCE` listed do-not-repeat; ambiguous ⇒ `UNKNOWN` | Never assume done or undone; repeat prevention is C4's | SC-06 |
| **SCN-INT-03** | `W1…W5`, stop after `W3` | Resume | `W1,W2` complete with evidence; `W3` partial; rest not started; no-marker variant `unknown` | A non-verified item labelled complete = hard failure (`false_completion`) | SC-03 |
| **SCN-INT-04** | Long session with protected spans | Compaction (size or context-limit trigger, twice) | Spans verbatim, hedges intact, pointers resolve, durable record byte-unchanged | Spans cannot fit ⇒ fail loud | SC-08, SC-18 |
| **SCN-RES-01** | A frozen resumption record and sources only | Fresh executor resumes blind | Correct done / remaining / do-not-repeat / blocked / constraints / provenance | Answer relying on information outside the record = failure | SC-12 |
| **SCN-RES-02** | Snapshot with a damaged component | Resume | Component named; regenerable parts regenerated with diff; else `UNVERIFIED`/`BLOCKED` | Protected spans never guessed or left empty | SC-04 |
| **SCN-RES-03** | Approval-time `repo_snapshot_id` differs from current snapshot | Resume | **C3 side only:** drift detected and reported | Blocking execution is C2/C4 | SL-13 |
| **SCN-PRV-01** | Claim/Evidence/Source/Verification chain variants | Resume and compact | Inert evidence does not advance a Claim; chain-only check weaker than content review; links preserved | No self-certification; no edit-in-place | SC-14 |
| **SCN-PRV-02** | Items with origin and scope labels | Checkpoint, resume, compact | Labels unchanged, never upgraded; missing label stays unlabelled/`UNVERIFIED`, not defaulted trusted | What a label means for trust is C2's | SC-17, SC-08 |
| **SCN-SAF-01** | Freshness source unreachable, unattended | Resume | `UNVERIFIED`; steps needing approval held/denied | Conditional on unattended scope existing (UNKNOWN) | SC-13 |
| **SCN-SAF-02** | Missing policy decision | Any cross-scope access or resume | Deny / hold | Never default allow | SC-07 |
| **SCN-SAF-03** | Evidence Source unresolvable | Cite toward a Claim | Retained but inert | Never deleted, never counted | SC-14 |

### 3.1 Detailed cases

Every case lists **setup, steps to reproduce, expected behavior, failure condition, required logs/evidence**. "Expected behavior" is what the *proposals* (CTX-001/002/004, C3 E3–E6) say should happen; it is the hypothesis, not an observed result. Repetition counts per case are **THRESHOLD NOT SET** (see TS-1). Every case below currently has status `TEST SPECIFIED`; none has been executed.

Baseline arms compared in every group once a harness exists:

- **B0** — reconstruct by re-reading every source and replaying prior session text.
- **B1** — resume from a summary of the prior session, no freshness check.
- **Proposed** — behavior described by CTX-001/002/004 (validate references, regenerate what changed, emit diff).

### Group A — Context isolation (extends C3 E4)

**Hypothesis.** Assembly-time scoping with explicit Dependency records prevents claims, excerpts, evidence, decisions and hidden assumptions from crossing between concurrent tasks; a failure leaks only through a case this group enumerates.

#### SC-01 — Two concurrent tasks with conflicting claims
- **Setup.** FX-REPO-1 at snapshot R0. Task X scope `SX` holds `DOC-03` (retry = 3); task Y scope `SY` holds `DOC-07` (retry = 5); `DOC-05` is a shared immutable source explicitly referenced by both. Canaries and decision records per task. Both tasks ask "what is the retry limit?"
- **Reproduce.** Run X and Y with three orderings (X first, Y first, interleaved). Build both context snapshots and answers. Scan packets, outputs, caches and logs for the other task's canary, decision record and source id.
- **Expected.** X's packet contains `DOC-03` and not `DOC-07`/`CNRY-Y`/`D-Y-*`; Y's the reverse. `DOC-05` appears in both **by reference** with its label intact. Each answer cites its own source. No silent merging of 3 vs 5; a conflict is surfaced only if an explicit Dependency record links the tasks. Source-defined default being tested (C1 Correction §6): a new Task Packet "never inherits any prior task's Context Packets, Claims, or Evidence Records by copy"; the only linkage is an explicit `references_task_id` (user request, or a Dependency recorded by C1).
- **Failure.** Any private item, canary, decision, or assumption of one task in the other's packet, output, cache entry, or log; conflicting claims merged silently; shared item's label lost.
- **Evidence.** Per-packet item-id lists; `ISOLATION_FILTERED` counts; canary-scan result; cache-key listing; run id and fixture hash.
- **Independent oracle (§2.3).** O3, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-07 — A task tries to access another task's private context
- **Setup.** Task Y attempts to read X's private items four ways: retrieval query, direct item id, cache lookup, and a lineage/freshness query. FX-POLICY-STUB modes: `deny`, `allow+Dependency`, `no_decision`.
- **Reproduce.** Run each access path under each stub mode; record responses for an existing-private item and a nonexistent item.
- **Expected.** `deny` → no content, logged without content; responses for "exists but forbidden" and "does not exist" are **indistinguishable** (no existence oracle). `allow+Dependency` → served with scope/origin label. `no_decision` → held/denied (fail closed).
- **Failure.** Content returned under `deny`; distinguishable responses; cross-scope cache hit; `no_decision` treated as allow.
- **Evidence.** `POLICY_DECISION_CONSULTED`, `ACCESS_RESULT` per path and mode; response-equivalence comparison.
- **Independent oracle (§2.3).** O8, O3. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.
- **Boundary.** The plan tests only that C3's assembly consults a decision and fails closed. What counts as authorized, and any trust or binding semantics, are **C2's** and are not defined here.

#### SC-11 — Hidden-assumption leakage through caches and derived items
- **Setup.** Task X writes a derived summary containing its assumption (`D-X-1`). Task Y later runs; a derived item is also built from inputs of both tasks.
- **Reproduce.** Run X, then Y; inspect cache keys and the scope of the mixed derived item.
- **Expected.** Cache keys include scope, so Y cannot reuse X's summary. The mixed derived item inherits the **strictest** scope and is served to neither task alone unless a rule says so.
- **Failure.** Y's output or packet reflects "retry = 3" without a Dependency record; derived item served under a weaker scope; a scope label stripped by a transform.
- **Evidence.** Cache-key listing with scopes; derived-item scope labels; canary scan.
- **Independent oracle (§2.3).** O3, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

### Group B — Stale-state detection (extends C3 E3, E6)

**Hypothesis.** Comparing versions recorded in the context snapshot's freshness manifest detects changed, moved and missing sources without re-reading unchanged ones, and the three questions in §1.2 are reported separately.

#### SC-02 — Source changes after a checkpoint, before resumption
- **Setup.** `CP-2` references `DOC-03` (version v1) and `DOC-05`. After `CP-2`, `DOC-03` is edited (retry 3→4) and repository `head` advances; `DOC-05` is untouched.
- **Reproduce.** Create `CP-2`; apply the edit; resume.
- **Expected.** Freshness check by version comparison marks `DOC-03` `CHANGED` and `DOC-05` `UNCHANGED`. The diff names `DOC-03`. Claims that cited `DOC-03` are flagged for re-verification, not carried as still verified (C3 E6: a Claim must not advance past `asserted` on a broken or changed Source). `DOC-05` is **not** re-read unless a stated reason exists.
- **Failure.** `DOC-03` treated as fresh; changed item silently replaced with no diff; dependent claim keeps its prior status.
- **Evidence.** `FRESHNESS_CHECKED` per item (old/new version), `DIFF_EMITTED`, `SOURCE_READ` events (to count unnecessary rereads).
- **Independent oracle (§2.3).** O2, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-05 — Checkpoint references an artifact that no longer exists
- **Setup.** `CP-3` references `DOC-09` and an evidence record. Variant (a): `DOC-09` deleted. Variant (b): `DOC-09` moved to a new path with identical content.
- **Reproduce.** Create `CP-3`; apply (a) or (b); resume.
- **Expected.** (a) `MISSING`; dependent claims `UNVERIFIED`; the **reference is preserved in the record**, not dropped. (b) reported as a **candidate relocation requiring confirmation**; it is not silently re-bound as the same object. Whether auto-binding on hash match is allowed is a **decision, not set here**.
- **Failure.** A dangling reference served as present; dependent claim stays verified; the reference silently removed (evidence loss).
- **Evidence.** `FRESHNESS_CHECKED` with outcome and reason; diff entry; preserved reference listing.
- **Independent oracle (§2.3).** O2, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-09 — Identity vs. freshness vs. semantic correctness
- **Setup.** Six sub-cases on `DOC-04`: (i) file touched, content identical; (ii) moved, content identical; (iii) whitespace-only edit; (iv) material edit; (v) `DOC-04` unchanged but the document it depends on (`DOC-11`) is revised so `DOC-04`'s claim is now wrong; (vi) `DOC-04` unchanged and its claim was wrong from the start.
- **Reproduce.** Apply each sub-case to a fresh copy; resume; record the three answers separately.
- **Expected.** (i) identity same, content-freshness `UNCHANGED`; touch alone is not a content change. (ii) identity: candidate relocation; freshness: undetermined until confirmed. (iii),(iv) `CHANGED`; semantic re-verification flagged. (v),(vi) freshness `UNCHANGED`, **and the record states that freshness does not establish correctness**; (v) is detectable only if a dependency link was recorded, otherwise it is an **expected miss to be documented, not hidden**.
- **Failure.** Any report that conflates the three questions; `UNCHANGED` promoted to "verified/correct"; (v) or (vi) reported as confirmed correct; a touch-only change counted as content change without being labelled a metadata signal.
- **Evidence.** Three separate result fields per sub-case; dependency links consulted; false-positive/false-negative tally by sub-case.
- **Independent oracle (§2.3).** O2, O1, O7 (sub-cases v, vi). The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-13 — Unattended resume with undeterminable freshness (conditional)
- **Applicability.** Only if unattended or scheduled execution is in scope, which is **UNKNOWN** (C5 P8, owners C1/C2).
- **Setup.** A resume with no human present; the freshness source (remote) is unreachable.
- **Expected.** Outcome `UNVERIFIED`; steps that require human approval are held or denied, never auto-promoted (C5 P8 fail-closed). An operator-facing view recomputes the outcome at read time rather than caching it (C5 E8).
- **Failure.** `UNVERIFIED` treated as `FRESH`; a stale outcome displayed after a state flip.
- **Evidence.** `FRESHNESS_CHECKED{result=UNVERIFIED}`; the hold/deny event; timestamp of the displayed outcome versus the live outcome. Display behavior is **C5-owned**; C3's requirement is only that the outcome carries `checked_at` and `checked_by`.
- **Independent oracle (§2.3).** O1 (remote made unreachable by the harness). The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

### Group C — Interruption and context reconstruction (extends C3 E5)

**Hypothesis.** Reconstruction depends only on recorded state and source versions, not on which interruption occurred, and can avoid re-reading everything without treating incomplete work as complete.

#### SC-03 — A partial result must not be mistaken for complete
- **Setup.** Work items `W1…W5`; interruption after `W3`; `W1,W2` verified complete with evidence; `W3` left partial (truncated output, in-progress marker); `W4,W5` not started. Variant: checkpoint written mid-`W3` with **no** state marker.
- **Reproduce.** Run to the interruption point; resume.
- **Expected.** `W1,W2` complete with evidence refs; `W3` partial and unverified; `W4,W5` not started; the marker-less variant labelled `unknown`, never complete. No completion claim is emitted.
- **Failure.** Any non-verified item labelled complete (the C6 `false_completion` canary: a hard failure by definition, not a soft flag); `W3`'s partial output used as final evidence.
- **Evidence.** State table with evidence refs per item; `RECONSTRUCTION_COMPLETED`.
- **Independent oracle (§2.3).** O1, O7. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-04 — Resume with one missing or corrupted component
- **Setup.** Four damaged variants of one snapshot: (a) truncated item list, (b) missing freshness manifest, (c) schema-version mismatch, (d) missing protected-span list.
- **Reproduce.** Load each variant and resume.
- **Expected.** The unusable component is **named**; what is regenerable from sources (e.g., the manifest from Task Packet + snapshot) is regenerated with a diff; what is not is `UNVERIFIED` or `BLOCKED`. Protected spans are **never** substituted with a guess or silently left empty.
- **Failure.** Silent partial load; defaults substituted without a marker; empty protected-span list accepted.
- **Evidence.** `COMPONENT_VALIDATED` per component; regeneration events; final labels.
- **Independent oracle (§2.3).** O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.
- **Open decision.** Which components may be regenerated versus force `BLOCKED` is **not decided here** (§5, §7).

#### SC-08 — Compaction removes low-priority content but preserves constraints and provenance
- **Setup.** FX-SESSION with `C-01`, `C-02`, `C-03`, `H-01` and five evidence-provenance links among low-priority chatter. Two triggers: proactive (size) and reactive (context-limit), mirroring the two-trigger structure in C3 P6. A variant compacts twice (summary of a summary).
- **Reproduce.** Run to each trigger; inspect the compacted active context and the durable store.
- **Expected.** `C-01…C-03` present verbatim; `H-01` still hedged; every retained claim keeps a resolvable source pointer; collapsed content is recorded and resolvable (cf. the `excluded_note` field named in C3 P5); the **durable record is byte-unchanged** (C6 Pattern 4: compression applies only to the active context); the provenance chain survives the second compaction.
- **Failure.** Any constraint absent or altered (negation flip, changed number); hedge removed; unresolvable pointer; durable record modified.
- **Evidence.** `COMPACTION_PERFORMED`, `PROTECTED_SPAN_CHECK{detected,present,fallbacks}`, hash of the durable store before/after.
- **Independent oracle (§2.3).** O5, O3 (protected-span search over raw output). The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.
- **Gate.** Meaningful only if the P15 pre-experiment shows compression is needed at ARGON's real session lengths.

#### SC-10 — Interruption trigger and point variants
- **Setup.** One task interrupted at each of `P1…P5` by each trigger: rate limit, timeout, context compaction, operator pause (flow owned by C5), killed session.
- **Reproduce.** 5 points × 5 triggers; resume each; compare resumed contexts.
- **Expected.** For the same recorded state, resumed contexts are **equivalent regardless of trigger**. Only changed or unverified sources are re-read; unchanged ones are verified by version, not reread.
- **Failure.** Resumed state differs by trigger for identical recorded state; mislabeled item state at any point; wholesale rereading (recorded as a cost finding, M6, not by itself a correctness failure).
- **Evidence.** `RECONSTRUCTION_*`, `SOURCE_READ` with reasons, state tables compared across triggers.
- **Independent oracle (§2.3).** O1, O2. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

### Group D — Safe resumption and resumption-record completeness

**Hypothesis.** A resumption record containing §1.1's fields lets a fresh executor resume correctly, and the context-side information it supplies is sufficient for C4 to avoid repeating a completed external effect.

#### SC-06 — Resume from a verified partial state without repeating a completed external side effect
- **Setup.** At step 3 the task performs external effect `SE-001` against FX-SINK-1. Three variants: (a) effect completed, evidence recorded, state note written; (b) effect completed, interruption before the state note; (c) effect completed at the sink, evidence record missing.
- **Reproduce.** Run to the interruption; resume; read FX-SINK-1.
- **Expected (C3 side).** (a) `SE-001` `COMPLETED_WITH_EVIDENCE` and listed in `do_not_repeat_without_confirmation`. (b),(c) `SE-001` `UNKNOWN`: **not assumed done and not assumed undone**, flagged for C4's idempotency decision.
- **Failure (C3 side).** A completed effect missing from the do-not-repeat list; an ambiguous effect labelled `NOT_ATTEMPTED`.
- **Failure (attributable to C4).** The resumption record was correct but a second attempt reached FX-SINK-1.
- **Attribution rule.** The two failures are **recorded separately**. This plan does not specify how C4 prevents repetition.
- **Evidence.** `RESUMPTION_RECORD_WRITTEN` (external-effects section), `EXTERNAL_EFFECT_ATTEMPT_OBSERVED` count per run.
- **Independent oracle (§2.3).** O4, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

#### SC-12 — Resumption-record completeness (blind resume)
- **Setup.** A frozen resumption record for a five-item task plus the referenced sources. A **fresh executor with no other context** is given only that record and the sources and asked a fixed question set: what is done, what remains, what must not be repeated, what is blocked, which constraints apply, which sources are provenance for which claims.
- **Reproduce.** Run the question set; grade against ground truth from the fixture.
- **Expected.** All answers match; every §1.1 field present.
- **Failure.** Any wrong answer about completion or do-not-repeat; any missing required field; an answer that relies on information not in the record.
- **Evidence.** Field-presence checklist; question-by-question grading; the record hash.
- **Independent oracle (§2.3).** O7, O1. The engine's own report is the thing under test, not the oracle.
- **Status.** `TEST SPECIFIED`; not executed.

### Group E — Evidence chain, Projection staleness, concurrent resumption

**Hypothesis.** The Claim→Evidence→Source→Verification chain and Context Packet lineage survive resumption intact and gated; concurrent resumers do not contaminate each other.

#### SC-14 — Evidence-chain integrity across resumption (Claim → Evidence Record → Source → Verification Record)
- **Setup.** FX-EVIDENCE-1. Variants: (a) all sources `resolvable`; (b) one Source `unresolvable`; (c) one Source `not_yet_checked`; (d) Source resolvable at citation, `unresolvable` at resume (SL-12); (e) Claim verified only by `chain_resolution_check`; (f) Claim verified by chain check **and** content review recorded as separate Verification Records; (g) a Claim verified by the same Cloud that produced it; (h) a correction to an Evidence Record's class.
- **Reproduce.** Build the context for each variant; interrupt; resume; run O6 on both the pre- and post-resume sets.
- **Expected (from C3 Knowledge v2 §4, §5, §7 and C1 Kernel items 9–10).** (b),(c),(d): the Evidence Record is retained but **inert**; the Claim does not advance past `asserted` (and a previously advanced Claim is flagged on resume). (e) is recorded as weaker than (f); chain resolution is "necessary, not sufficient," and the two are never collapsed into one unqualified PASS. (g) is rejected: no Claim is `VERIFIED` by its producing Cloud. (h) a correction is a **new** record, never an edit. All referential links resolve after resume. No Claim loses an Evidence link through compaction or resumption.
- **Failure.** An inert Evidence Record counted toward Claim status; a chain-only check reported as full verification; self-certification accepted; an evidence link dropped, edited in place, or left dangling.
- **Evidence.** `CHAIN_CHECKED` per Claim; O6 result before/after; Evidence integrity count (C6 metric; target 0 is C6's definitional target).
- **Boundary.** Verification **method** and verdict authority between C6 and C7 are unresolved (C3 Knowledge v2 §8 options A/B/C; no choice here). This case tests only that the chain is preserved and gated as the schema states.

#### SC-15 — Context Packet built under an outdated Context Projection version
- **Setup.** Packet `K1` built under Projection `PJ` v1. `PJ` advances to v2 (SL-09). Variants: (a) v2 changes which files the rule pulls; (b) v2 changes nothing material (the case must not pretend to know which; it only records the result).
- **Reproduce.** Create `K1`; advance `PJ`; resume.
- **Expected.** `PROJECTION_VERSION_CHECKED` shows `packet_version` behind `current_version`; `K1` is flagged for regeneration; it is **not** silently reused as current. The regenerated Packet is a new immutable instance; `K1` is retained, not edited.
- **Failure.** `K1` served as current; `K1` edited in place; regeneration with no record of the version change.
- **Evidence.** Event with both versions; Packet ids; diff of file lists.
- **Dependency.** Requires the Context Packet field names to be reconciled between C1 Correction §2 and C3 Knowledge v2 §2 (§5). **No refresh period is implied.**

#### SC-16 — Concurrent resumption of one checkpoint reference (conditional)
- **Applicability.** Only meaningful once a lease/concurrency rule exists. C4 pack U2 records that **no lease or concurrency primitive is defined by C3**; whether it exists, and who owns it, is `UNKNOWN`.
- **Setup.** Two resumers (R1, R2) resume the same checkpoint reference at the same time, with the same recorded state.
- **Expected (C3 side).** Each resumed context is built independently from recorded state and sources; neither contains the other's reconstruction diff, partial output or labels unless a recorded Dependency links them; both are equivalent for equal recorded state. **Which resumer may proceed is not tested here** (lease/ownership: undefined; side-effect protection: C4).
- **Failure (C3 side).** One resumer's in-progress labels or diff appear in the other's context; non-equivalent contexts from equal state.
- **Evidence.** O3 scan across both contexts; equivalence comparison; O4 counts reported to C4 without attribution to C3.

#### SC-17 — Origin and scope labels survive resumption without being upgraded
- **Setup.** Fixture items carrying origin labels (first-party fixture document, retrieved external-text fixture, tool-result fixture, operator-supplied note) and scope labels, plus one item with **no** label. Checkpoint, resume, and a compaction pass.
- **Reproduce.** Record labels before; interrupt; resume; compact; record labels after (O1 table, O3 scan).
- **Expected.** Every label identical after resumption and compaction; none upgraded to a more trusted value; the unlabelled item stays unlabelled (or `UNVERIFIED` origin) and is **not** defaulted to trusted; transformed or derived items inherit the least-trusted source label.
- **Failure.** Label stripped, upgraded, or defaulted to trusted; derived item carrying a more trusted label than its inputs.
- **Evidence.** Label table before/after; derived-item lineage.
- **Boundary.** What a label *permits* is C2's decision; this case checks only that C3 preserves it. CTX-004 is C3's proposal, not canon.

#### SC-18 — Protected spans cannot fit the available room (safe failure)
- **Setup.** FX-CONSTRAINTS and FX-SESSION; the harness imposes an artificially small room limit chosen only to force the condition. **The limit is a test lever, not a recommended budget.**
- **Expected.** Fail loud: the shortfall is reported with the spans named; no protected span dropped, truncated, paraphrased or silently moved to a lower-priority region.
- **Failure.** Any span lost or altered; failure reported only in a log nobody consumes; a "best effort" answer produced without the shortfall marker.
- **Evidence.** `PROTECTED_SPAN_CHECK{detected,present,fallbacks}`; the failure marker; O3 search over the output.

---

## 4. Metrics and Threshold Gaps

No numeric threshold is invented. A bar appears only where an artifact itself sets it, and is cited as that artifact's own. Everything else is `THRESHOLD NOT SET`.

| ID | Measurement | Unit / method | Cases | Threshold status | Experiment to set it |
|---|---|---|---|---|---|
| **M1** | Context isolation failures | Count of canaries, claims, decisions or evidence of one task found in another's packet, output, cache or log without a Dependency record; existence-oracle events (O3) | SC-01, 07, 11, 16 | **Zero** is the source-defined requirement (C3 E4; C1 Corr. §6 makes leakage "a rule violation"). **N (trial count) NOT SET** | TS-1 |
| **M2** | Missing critical constraints after compaction | Protected spans lost or altered; hedges removed | SC-08, SC-18 | Zero loss is CTX-002 (C3's own proposal, not canonical); acceptable fallback rate **NOT SET** | TS-2, P15 |
| **M3** | Stale-source detection | Detection and false-positive rate per condition SL-01…SL-13 (O1, O2) | SC-02, 05, 09, 15 | C3 E3's 100%/0% applies to SL-01 only; **all other bars NOT SET**; touch-only and move-with-same-hash policy needs a decision | TS-3 |
| **M4** | Reconstruction correctness | Agreement of completed/partial/not-started/unknown labels with O1/O7; **false-completion count** | SC-03, 04, 10, 12 | False completion = **zero by C6's definition**; other label accuracy **NOT SET** | TS-4 |
| **M5** | Duplicate side-effect attempts on resume | Attempts at FX-SINK-1 beyond the first (O4), attributed per SC-06 | SC-06 | C5 E5 treats any duplicate as failure; no overall bar set here; C3/C4 attribution kept separate | none for the C3 part |
| **M6** | Context size, retrieval cost, latency, unnecessary rereads | Tokens in resumed context; bytes and count of reads; wall-clock; reads of unchanged sources | SC-02, 08, 10 | **NOT SET.** No token budget, tier ceiling or compression window is set | TS-5 |
| **M7** | Resumption-record completeness | Required fields present; blind-resume answers correct | SC-12 | Field presence mechanical; answer-accuracy bar **NOT SET** | TS-4 |
| **M8** | Evidence/log completeness | All required events present; no content bodies logged | all | Mechanical: all required events present | none |
| **M9** | Evidence-chain and label integrity | Count of inert/unresolvable evidence cited toward Claim advancement; dangling links; self-certified Claims (O6); label upgrades/strips (SC-17) | SC-14, SC-17 | **Zero by C6's definitional target** ("Evidence integrity") | none |
| **M10** | Projection-version staleness detection | Detected / missed outdated Packets (O1) | SC-15 | **NOT SET** | TS-3 |

### 4.1 Experiments that set the missing thresholds

| ID | Purpose | Method (no values set) |
|---|---|---|
| **TS-1** | Repeat-count and variance | Run each case repeatedly under ordering variations on the dev set until variation in M1/M3 stabilizes; stopping rule recorded before running |
| **TS-2** | Compaction baseline | Measure M2 under plain collapse (C3 P5 pattern) and B1 on the dev set; interpret only after P15 fixes realistic session length |
| **TS-3** | Staleness policy | Measure false-positive/negative rates per SL condition under candidate signals; touch-only, move-with-same-hash and any age-based policy are **decisions** informed by the rates |
| **TS-4** | Label accuracy | Human-label ground truth (O7) for state labels and blind-resume questions; measure B0, B1, Proposed |
| **TS-5** | Cost baseline | Measure M6 for B0 vs B1 vs Proposed; any budget must come from this baseline, not vendor constants |

All TS experiments use the dev/held-out split; thresholds are fixed on the dev set and claimed on the held-out set (C3 P10).

---

## 5. Decisions This Plan Cannot Make

| Decision | Why open | Owner (per brief) | Status |
|---|---|---|---|
| **Checkpoint object ownership** | Artifacts disagree (§6.2) | C1 ratifies cross-cloud contracts; **no owner chosen here** | `REQUIRES HUMAN DECISION` / C1 Synthesis |
| Whether a checkpoint reference may point to a **context snapshot** (C1 L219 limits it to the Repository Snapshot) | Extends C1's definition | C1 ratifies | `OPEN` |
| Context Packet field names (C1 Corr. §2 (H) vs C3 Knowledge v2 §2) | Two lists in two Wave 3.5 files | C3 schema; C1 ratifies | `OPEN` |
| Handoff Record producer (C3 Knowledge v2 §3 vs C1 Corr. §3) and relation of a *resumption record* to it | Files disagree | C3 / C1 | `OPEN` |
| Approval Record field list (C3 v2 §6 vs C1 Corr. §5) and the checkpoint-reference field | Two lists; C1 L221 names an open schema gap | C3 schema; C2 enforcement; C1 placement | `OPEN` |
| Wave 3.5 **Convergence Patch v3** content (Approval hash-binding §4; status vocabulary) | File not in repository | C1 | `BLOCKED` — missing artifact |
| Freshness window / age-based staleness (SL-14) | C1 Corr. §7 (H)'s 15 minutes is a flagged judgment call | Human confirmation; C3 proposes | `THRESHOLD NOT SET` |
| Snapshot components regenerable vs forcing `BLOCKED` (SC-04) | No artifact decides | C3 proposes; C1 ratifies | `OPEN` |
| Moved same-hash file auto-re-bind (SC-05, SL-06) | Identity policy undefined | C3 proposes; C1/C2 decide | `OPEN` |
| Touch-only (mtime) policy (SL-04) | False-positive tolerance undefined | C3 with C6 measurements | `OPEN` |
| Unattended/scheduled execution exists? (SC-13) | `UNKNOWN` (C5 P8) | C1/C2 | `UNKNOWN` |
| Lease/concurrency primitive for resumption (SC-16) | C4 pack U2: not defined | C1/C4 | `UNKNOWN` |
| Tier scheme T0–T5 and ceilings | T1–T3 undefined; ceilings undefined | C1 | `UNKNOWN` |
| State-only vs audit-preserving resume | C5 research: "needs C6 to say" | C5/C6 | `UNKNOWN` |

---

## 6. Ownership and Dependency Matrix

Assignments follow the prompt-pack brief. Where a current artifact supports, contradicts or is silent on an assignment, that is stated. **No ownership is derived merely from who evaluates a test.**

| Concern | C1 | C2 | C3 | C4 | C5 | C6 | Grounding / status |
|---|---|---|---|---|---|---|---|
| Context semantics, isolation, freshness, provenance, context-resumption **requirements** | ratifies cross-cloud contract | trust-label inputs | **Owns** | consumes | displays | consumes metrics | Brief; C3 research §3/§4; C7 lists isolation as open |
| Cross-cloud contracts, pipeline placement, Kernel rules (e.g., "a checkpoint must exist") | **Ratifies / owns** | — | provides context state | executes within | — | — | Brief; C1 research Kernel items 7–10. **C1 Synthesis v2 does not exist**, so ratification is `PENDING` (DEP-03) |
| Authorization decision before resumption or access | consults | **Owns** | **Consults** a decision, fails closed | — | — | — | Brief; C2 RP-7/9/11. Tested only as consultation + fail-closed. RP-13 binding `NEEDS EXPERIMENT` (OQ-01) and not used here |
| Mutations, execution, idempotency, side effects, rollback | — | — | supplies `external_effects[]` semantics | **Owns** | — | — | Brief. C4 protocol Pattern D (one edit = one revertible commit); **C4 pack Pack 001** is a proposal (journal) and its own §8 lists U1, U2 as open. Not specified here |
| Operator-facing pause / resume / intervention | — | — | outcome carries `checked_at`, `checked_by` | — | **Owns** | — | Brief; C5 packs v2 Pack 5 (blocked on C1/C2), C5 E5/E8/P8/P10 |
| Evaluation method; interpretation of results | — | — | defines cases, oracles, metrics (proposals) | — | — | **Owns method** | Brief; C6 §3 metrics. **C6 future packs absent** (DEP-07) |
| **Checkpoint object ownership** | candidate | candidate | semantics of referenced context only | not execution-side rollback | blocked-on | **not assigned** | **OPEN** — see §6.2 |
| Independent audit | — | — | — | — | — | — | **C7** |

### 6.1 Exact outstanding dependencies

| Cloud | Dependency (needed before a case can be executed or a threshold set) | Register link |
|---|---|---|
| **C1** | (1) Cross-Cloud Synthesis v2; (2) ratify Context Packet / Handoff Record / Approval field reconciliation; (3) decide whether a checkpoint reference may point to a context snapshot; (4) checkpoint ownership and **invalidation rule**; (5) T0–T5 definition; (6) location of the missing **Convergence Patch v3**; (7) whether unattended execution exists; (8) Wave 4 harness that exposes the §2.1 observables | DEP-03, DEP-10, OQ-06 |
| **C2** | Real decision source replacing FX-POLICY-STUB (SC-07); Approval hard-gate enforcement; RP-13 is **not** assumed | OQ-01, DEP-09 |
| **C4** | Idempotency / duplicate-effect mechanism replacing "none" at FX-SINK-1 (SC-06, SC-16); lease primitive; Plan/Act journal if adopted; 5th-vector taxonomy (not this plan's subject) | OQ-02, OQ-03 |
| **C5** | Pause/resume flow, unattended scope, state-only vs audit-preserving resume | C5 packs v2 Pack 5 |
| **C6** | Evaluation method and interpretation of results; the Future Capability Pack; verification-authority conflict options (C3 v2 §8) | DEP-06, DEP-07 |
| **C3 (own)** | P15 pre-experiment; Wave 4 fixtures built and frozen; TS-1…TS-5 baselines | — |

No dependency row for this plan exists in `DEPENDENCY-REGISTER.md`. Proposed text is in `proposals/C3-REGISTER-UPDATE-SNIPPETS.md` for the integration owner; the registers were **not** edited.

### 6.2 Checkpoint ownership — what each source says (no owner chosen)

| Source | Statement | Where |
|---|---|---|
| C3 research P9 | Checkpointing "is C1/C2 territory"; "flagged for C1, not adjudicated here" | `clouds/C3/…` L137 |
| C1 research Pattern 5 and Kernel items 7 | Rule "a checkpoint must exist" = **Kernel**; mechanism = **Runtime**; what is checkpointed = the **Repository Snapshot at approval**, not conversational context; checkpoint-reference field on Approval Record = **open schema gap**; invalidation = **UNKNOWN** | `clouds/C1/…` L189–L224, L360–L377 |
| C5 research | Checkpoint is "still-open **C6** checkpoint dependency" | `clouds/C5/…` L489, L640 |
| C5 packs v2 N1 | Ownership correction: owner is **C1 (and C2)**, not C6; Pack 5 "blocked on C1/C2" | `capabilities/future/C5/…` L48, L117 |
| C4 packs Q5, U1 | Ownership gap: "C5 assigns the dependency to C6; C6 has no checkpoint content; C3 owns the snapshot. Pack 001 assumes Synthesis picks a storage owner (**C3 or C6**)" | `capabilities/future/C4/…` L60, L322 |
| C6 research | **Zero** checkpoint/resume content (keyword search this run) | `clouds/C6/…` |

The sources split three ways (C1/C2; C6; C3-or-C6 for storage). The brief forbids assigning it to C6 merely because C6 evaluates. **This plan assigns it to nobody.** It needs a C1 Synthesis decision or a human decision.

### 6.3 Boundary rules (restated)

C3 never starts, retries, reorders, rolls back or authorizes anything. C4 never edits snapshots or freshness records. This plan defines no execution mutation, no rollback, no authorization, no cryptographic binding and no checkpoint storage.

---

## 7. Failure Behavior, Evidence Preservation, Result Statuses, Regression Retention

### 7.1 Expected behavior on failure (hypotheses to test, PROPOSED)

| Condition | Expected behavior |
|---|---|
| Freshness cannot be determined | `UNVERIFIED`; usable only with the marker visible; held in unattended runs |
| Component missing or corrupted | Name it; regenerate what is regenerable; else `UNVERIFIED` / `BLOCKED`; never guess protected spans |
| Reference to a missing artifact | `MISSING`; preserve the reference; dependents `UNVERIFIED` |
| External-effect status unknown | `UNKNOWN`; listed for C4's decision; neither done nor undone assumed |
| Access without a policy decision | Deny / hold |
| Protected spans cannot fit | Fail loud; never drop |
| Evidence Source unresolvable | Evidence inert; Claim does not advance |

### 7.2 Evidence preservation for the experiments

- Each run records: fixture id and hash, split, run id, ordering variant, event log, snapshot and resumption-record hashes, diffs, durable-store hash before/after, the oracle outputs (O1–O8), and the engine and Projection versions under test.
- Run artifacts are **append-only.** A failed run is never overwritten or relabeled; a re-run gets a new run id.
- Logs carry ids, versions, hashes, counts; never source bodies.

### 7.3 Result statuses and the TEST SPECIFIED / TEST EXECUTED ledger

Vocabulary is the program's own; nothing new is added.

| Status | Meaning here |
|---|---|
| `DESIGNED` | The plan exists as a design (this document) |
| `NOT_IMPLEMENTED` | No harness, engine, checkpoint, memory service or isolation mechanism exists |
| `TEST SPECIFIED` | **Every item in the ledger below** |
| `TEST EXECUTED` | A run occurred and its evidence is attached; **no verdict is implied**, including for failed runs |
| `PASS WITH EVIDENCE` | Only after execution on the held-out set, thresholds set beforehand, complete §7.2 evidence, **C6 interpretation and C7 audit** |
| `NEEDS EXPERIMENT`, `UNKNOWN`, `BLOCKED`, `THRESHOLD NOT SET`, `REQUIRES HUMAN DECISION` | Preserved as in the sources; never upgraded here |

**Ledger (as of 2026-10-15).** `TEST EXECUTED` count: **0**. `PASS WITH EVIDENCE` count: **0**. Benchmarks run: **0**.

| Item set | Count | Status | Executed | Evidence attached | Blocked by |
|---|---|---|---|---|---|
| Detailed cases SC-01…SC-18 | 18 | `TEST SPECIFIED` | No | None | Wave 4 harness; frozen fixtures; C2/C4 stand-ins; per-case thresholds |
| Scenarios SCN-* | 20 | `TEST SPECIFIED` | No | None | Same |
| Staleness conditions SL-01…SL-15 | 15 | `TEST SPECIFIED`; SL-14 `THRESHOLD NOT SET` (not specifiable) | No | None | Freshness-window decision |
| Threshold-setting experiments TS-1…TS-5 | 5 | `TEST SPECIFIED` | No | None | Harness; dev set |
| Existing C3 E3–E6, P15 | 5 | `TEST SPECIFIED` (per `STATUS.md`) / P15 not run | No | None | — |
| Conditional: SC-13 (unattended), SC-16 (lease) | 2 | `TEST SPECIFIED`, applicability `UNKNOWN` | No | None | Scope decisions |

Execution-lifecycle detail (C6-owned): `TEST SPECIFIED → TEST EXECUTED → interpreted (C6) → audited (C7) → PASS WITH EVIDENCE`.

### 7.4 Regression-retention rules (PROPOSED method; C6 owns method and may change them)

1. **Retain failures forever as cases.** Any case that fails, and any defect found outside a case, becomes a permanent regression case with its fixture, oracle and run id preserved.
2. **Frozen fixtures.** A fixture, oracle table (O1) or canary set is never edited after a claim run. A change creates a new fixture id; the old one stays runnable.
3. **Held-out discipline.** A held-out set used to tune anything is reclassified as dev; a new held-out set is required before the next claim. (From C3 P10 / C6 Pattern 2.)
4. **Retirement needs a record.** A case is retired only with a written reason by its owner and C6, and its history is kept.
5. **Re-run triggers.** Re-run the retained set whenever the engine, a Context Projection version, the Repository Snapshot logic, the compaction logic, or a fixture version changes. **No re-run frequency or schedule is set.**
6. **Canaries are not reused across claim runs.** Fresh unique markers per run version, so residue from an earlier run cannot masquerade as leakage or hide it.
7. **Expected misses stay visible.** A documented expected miss (SL-08 without a dependency link) remains in the report as an expected miss in every later run until a link mechanism exists.

---

## 8. Closure Criteria and Remaining Unknowns

### 8.1 Closure criteria (per group)

A group closes only when **all** hold:

1. Cases run on a real implementation (not a mock of the engine) against frozen fixtures, on the held-out set.
2. Every `THRESHOLD NOT SET` the group depends on has been set by its decision owner from a TS baseline recorded **before** the claim run.
3. §7.2 evidence is complete for every run, including failed ones.
4. C6 has interpreted the results and C7 has independently audited them.
5. Each decision in §5 the group touches is resolved or explicitly recorded as open.
6. Where a case contradicts the proposal it tests, the proposal is changed or rejected through the owning Cloud's process, not edited here.

Group additions: **A** needs the Dependency-record field list; **B** needs the freshness-signal choice and SL policy decisions; **C/SC-08** needs the P15 result; **D/SC-06, SC-16** need C4's mechanism and lease rule; **E (SC-14, SC-15)** needs the reconciled Packet/Evidence field lists.

### 8.2 Remaining unknowns

- **Genuinely absent from `main`:** C1 Cross-Cloud Synthesis v2; C6 Future Capability Pack; Wave 3.5 **Convergence Patch v3**; Wave 3.5 C3 v1 knowledge model (field lists for Task Packet, Dependency, Claim, Source, Evidence Record, Cloud Result, Decision Reference); Wave 3.5 C4 context markdown.
- **Present but unreconciled:** Context Packet fields; Approval Record fields; Handoff Record producer; checkpoint ownership.
- The TXT `c2-c6(1).TXT` was not available, so this candidate's relation to lines 567–968 is **unverified**.
- Whether the proposals under test duplicate anything inside C1's design: C1's Pattern 5 and Kernel items cover checkpoint existence only; stale-state resumption is stated as **undesigned**, so no duplication was found, but C1 Synthesis v2 is the place it would be settled.
- Realistic ARGON session length (P15); T0–T5; whether unattended execution exists.
- External-source claims in C3 research (e.g., "Lost in the Middle" figures read via summaries; Aider 50×/8×) were not spot-checked by C7 and are used here as no threshold.
- **No test has been executed; no result exists.**

### 8.3 Suggested register text

Proposed entries are in a **separate file** for the integration owner (`proposals/C3-REGISTER-UPDATE-SNIPPETS.md`). No shared register or canonical file was edited.

---

## 9. Change Summary

**r3 vs r2 (reconciliation pass 2026-10-15):**
- Re-verified `main` unchanged at `71a3fa6d…`; intake branch is an ancestor; **no accepted C3 output on `main`**.
- Introduced artifact classes (CANONICAL, CURRENT_SUPPORTING, HISTORICAL, DUPLICATE, ABSENT, STAGING CANDIDATE, ACCEPTED OUTPUT) and re-classified every source (§0.3).
- **Found and fixed an r2 weakness:** Wave 3.5 rules (staleness triggers, isolation default, Packet fields) were cited as if current design; they are historical-class. Canonical C3 §4 says re-fetch trigger `UNKNOWN`. Now labelled "(H)" and treated as proposals (§0.4, §2.2).
- Reconciled with C7-FFA-003: it audits neither this plan nor C3's isolation/resumption design; no newer C7 report exists.
- Added §3.0 scenario catalogue (20 scenarios across isolation, stale data, interrupted execution, resumption, provenance, safe failure); added SC-17 (labels) and SC-18 (cannot-fit safe failure).
- Added the TEST SPECIFIED / TEST EXECUTED ledger (§7.3).
- Added source-to-claim map with exact paths and line ranges (`maps/`).

**r2 vs prior draft:** see `logs/C3-SOURCE-TRACEABILITY-AND-CORRECTION-LOG.md` (renamed "handoff record" → "resumption record"; added staleness conditions, oracles, evidence-chain and Projection-version cases, regression retention).

**Not adopted / not changed:** C1's 15-minute figure; any token budget, tier ceiling, retry value, compression window or leakage count above source-defined zero; any checkpoint owner. No canonical file, manifest, register, architecture decision or C1 synthesis was touched. No commit, push, branch, PR or merge. No implementation, memory service, checkpoint or isolation code exists; no case or benchmark has been executed.
