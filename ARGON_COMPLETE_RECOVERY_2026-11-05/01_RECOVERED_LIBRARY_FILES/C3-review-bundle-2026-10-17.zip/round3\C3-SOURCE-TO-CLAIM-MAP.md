# C3 — Source-to-Claim Map (exact paths and line ranges)

Baseline: AI-OS `main` `71a3fa6d1fb1eed0e694886263710d4020e10341`. Paths are repo-relative. Line ranges are 1-indexed inclusive and refer to the file at that commit.
Every row was **machine-checked**: a pattern naming the cited content was searched inside the stated range and found (`verified: yes`). A passing check shows the range contains the anchor, not that the candidate's reading of it is correct; interpretation remains reviewable.

Class: CANONICAL = `STATUS.md` canonical, hash-matched; CURRENT_SUPPORTING = future capability pack (`DESIGNED`); HISTORICAL = `archive/historical/` (not current canon); "(register)" = shared register; "(citation only)" = the file is cited but the cited artifact is not in the repo.

| ID | Claim in the candidate | Class | Path | Lines | Used in | Verified |
|---|---|---|---|---|---|---|
| CL-01 | `main` baseline and status: C1 synthesis v2 unwritten; no implementation; verdict CLEAN WITH OPEN EXPERIMENTS | CANONICAL | `STATUS.md` | 1–16 | §0.2, header | yes |
| CL-02 | C1 Cross-Cloud Synthesis v2 is ABSENT / primary blocker | CANONICAL (register) | `STATUS.md` | 24–24 | §0.3, §6.1 | yes |
| CL-03 | C6 Future Capability Pack is ABSENT | CANONICAL (register) | `STATUS.md` | 34–34 | §0.3, §6.1 | yes |
| CL-04 | C4 Wave 3.5 context markdown absent; only manifest | CANONICAL (register) | `STATUS.md` | 58–60 | §0.4 | yes |
| CL-05 | C1–C6 canonical hashes match baseline | CANONICAL (register) | `STATUS.md` | 39–46 | §0.3 | yes |
| CL-06 | OQ-06 Context Stale-State Resumption & Compaction = NEEDS EXPERIMENT | CANONICAL (register) | `planning/OPEN-QUESTIONS.md` | 45–48 | §0.5, §6.1 | yes |
| CL-07 | OQ-01 RP-13 binding open (not used by this plan) | CANONICAL (register) | `planning/OPEN-QUESTIONS.md` | 9–19 | §6 | yes |
| CL-08 | DEP-03 C1 Synthesis BLOCKED; DEP-07 C6 packs MISSING; DEP-06 C6 harness DESIGNED | CANONICAL (register) | `planning/DEPENDENCY-REGISTER.md` | 11–15 | §0.5, §6.1 | yes |
| CL-09 | No dependency row exists for C3 isolation/resumption experiments | CANONICAL (register) | `planning/DEPENDENCY-REGISTER.md` | 7–18 | §0.5, §6.1 | yes |
| CL-10 | NEXT-ACTIONS: ACTION-01 C1 synthesis; ACTION-02 C6 packs; ACTION-03 C7 FFA-004; no C3 action | CANONICAL (register) | `planning/NEXT-ACTIONS.md` | 7–29 | §0.5, §6.1 | yes |
| CL-11 | Future packs are DESIGNED/NOT_IMPLEMENTED/TEST SPECIFIED; C6 pack PENDING | CANONICAL (register) | `capabilities/capability-index.md` | 3–22 | §0.3 | yes |
| CL-12 | Intake outcome: duplicates, historical Wave 3.5 relocated; zero test runs | CANONICAL (register) | `docs/CURRENT-STATE.md` | 50–51 | §0.3, §7.3 | yes |
| CL-13 | C7 verdict; isolation, checkpoint resumption, E1b, E3 remain open pending an implementation environment | CANONICAL | `assurance/audits/C7-FFA-003.md` | 42–48 | §0.5 | yes |
| CL-14 | C7 does not audit C3 isolation/resumption design (Gates 3: C1 spot checks; Gate 4: Plan/Act and migration) | CANONICAL | `assurance/audits/C7-FFA-003.md` | 21–37 | §0.5 (C7 reconciliation) | yes |
| CL-15 | C7 final classification / verdict | CANONICAL | `assurance/audits/C7-FFA-003.md` | 50–73 | §0.5 | yes |
| CL-16 | Canonical C3: Context Projection vs Context Packet distinction | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 33–37 | §0.4, §1 | yes |
| CL-17 | Canonical C3 §3: isolation has no direct external precedent; closer to multi-tenant/distributed-systems problem | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 227–237 | §0.6, SC-01 | yes |
| CL-18 | Canonical C3 §4: staleness definition, `head` vs `origin_head`; re-fetch and recompile triggers UNKNOWN; no numeric threshold invented | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 239–251 | §0.4, §2.2, §5 | yes |
| CL-19 | C3 E3 stale-context detection experiment | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 284–284 | §0.6, §2.2 SL-01 | yes |
| CL-20 | C3 E4 context isolation experiment | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 285–285 | §0.6, §4 M1 | yes |
| CL-21 | C3 E5 compression loss; E6 evidence preservation | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 286–287 | §0.6, SC-08, SC-14 | yes |
| CL-22 | E3–E6 hold out validation set; none run; 100%/0% are correctness bars for deterministic operations | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 289–291 | §4 M3 | yes |
| CL-23 | C3 P9: checkpointing is C1/C2 territory | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 131–139 | §6.2 | yes |
| CL-24 | C3 P5 bounded history collapse; P6 event-sourced condensation (thresholds UNKNOWN) | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 87–104 | SC-08 | yes |
| CL-25 | C3 P15 pre-experiment: are sessions long enough to need compression | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 185–192 | §0.6, SC-08 | yes |
| CL-26 | E4 isolation-trial count N is NEEDS EXPERIMENT | CANONICAL | `clouds/C3/C3-CONTEXT-ENGINE-RESEARCH.md` | 402–402 | §4 M1 | yes |
| CL-27 | C1 Pattern 1: isolated subagent context is a harness property (different from task-context isolation) | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 35–76 | §0.6 | yes |
| CL-28 | C1 Pattern 5: checkpoint = Repository Snapshot at approval, not conversational context | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 219–219 | §1, §5 | yes |
| CL-29 | C1: checkpoint reference field on Approval Record is an open schema gap | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 221–221 | §0.4, §5 | yes |
| CL-30 | C1: stale-state resumption UNKNOWN/NEEDS EXPERIMENT; invalidation UNKNOWN | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 222–224 | §0.4, §0.5 | yes |
| CL-31 | C1 Kernel item 7: rule 'a checkpoint must exist'; mechanism is Runtime | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 360–360 | §6, §6.2 | yes |
| CL-32 | C1 Kernel items 9–10: self-certification exclusion; claim without resolvable reference | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 362–363 | SC-14 | yes |
| CL-33 | C1 layer table: checkpoint rule = Kernel, mechanism = Runtime | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 376–377 | §6.2 | yes |
| CL-34 | C1 closure: stale-state resumption and checkpoint invalidation genuinely undesigned | CANONICAL | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 495–495 | §0.4, §8.2 | yes |
| CL-35 | C1 cites Wave 3.5 Convergence Patch v3 (dependency); no such file on main | CANONICAL (citation only) | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 517–517 | §0.4, §5 | yes |
| CL-36 | C1 cites Convergence Patch §4 (Approval hash-binding) | CANONICAL (citation only) | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` | 202–202 | §0.4 | yes |
| CL-37 | Historical: Context Packet vs Projection split; Packet fields incl. projection_version; stale Packet flagged | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 30–40 | §0.4, SL-09, SC-15 | yes |
| CL-38 | Historical: single Handoff Record schema owned by C3; Cloud Result is pre-validation draft | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 42–58 | §0.4, §1, §5 | yes |
| CL-39 | Historical: Approval Record fields (approved_plan_ref, scope, approver=human); owners | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 100–117 | §0.4, §5 | yes |
| CL-40 | Historical: task-context isolation default; explicit references_task_id only | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 119–129 | §0.4, SC-01 | yes |
| CL-41 | Historical: four staleness triggers; 15-minute value flagged as judgment call | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 131–144 | §0.4, §2.2 SL-10/11/14/15 | yes |
| CL-42 | Historical: C3 must formally add schemas; C1 correction not implemented in C3's file | HISTORICAL | `archive/historical/wave3.5/C1-WAVE3.5-CORRECTION-v2.md` | 180–186 | §0.4 | yes |
| CL-43 | Historical: repo_target widened; Repository Snapshot git fields nullable | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 10–24 | §0.4 | yes |
| CL-44 | Historical: Projection/Packet split DESIGNED, requires C1 ratification | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 26–37 | §0.4 | yes |
| CL-45 | Historical: one canonical Handoff object; Handoff Record produced once per wave by C1 | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 39–58 | §0.4, §1 | yes |
| CL-46 | Historical: status axes processing_state, lifecycle_status, evidence_class, claim_status | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 60–72 | §0.4 | yes |
| CL-47 | Historical: Evidence inert unless Source resolvable; chain check necessary not sufficient | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 74–96 | §0.4, §2.2 SL-12, SC-14 | yes |
| CL-48 | Historical: Approval object fields incl. repo_snapshot_id, valid_until; ACT invariant | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 98–114 | §2.2 SL-13 | yes |
| CL-49 | Historical: referential integrity list | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 116–127 | §2.3 O6 | yes |
| CL-50 | Historical: C6/C7 verification-authority options A/B/C, no decision | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 129–141 | §5, SC-14 | yes |
| CL-51 | Historical: unchanged objects defined only in the absent v1 (carried forward 'see prior artifact') | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 143–146 | §0.4, §8.2 | yes |
| CL-52 | Historical: v1 model superseded; SHA 32114b7… (file absent from repo) | HISTORICAL | `archive/historical/wave3.5/C3-WAVE3.5-KNOWLEDGE-v2.md` | 4–4 | §0.4 | yes |
| CL-53 | Historical C6: Repository Snapshot verification fields; cross-task isolation hard-failure rule | HISTORICAL | `archive/historical/wave3.5/C6-WAVE3.5-VERIFICATION-MASTER.md` | 24–34 | §0.4 | yes |
| CL-54 | C6 T0–T5 tiering is referenced/proposed, not verified | CANONICAL | `clouds/C6/C6-CLOUD-EVALUATION-ENGINE.md` | 14–14 | §0.6, §5 | yes |
| CL-55 | C6 Pattern 2: train/validation/held-out separation | CANONICAL | `clouds/C6/C6-CLOUD-EVALUATION-ENGINE.md` | 40–56 | §2 dev/held-out, §7.4 | yes |
| CL-56 | C6 Pattern 4: compression applies to active context, not the durable record | CANONICAL | `clouds/C6/C6-CLOUD-EVALUATION-ENGINE.md` | 76–88 | SC-08 | yes |
| CL-57 | C6 metrics: Evidence integrity (target 0), Token efficiency, False completion | CANONICAL | `clouds/C6/C6-CLOUD-EVALUATION-ENGINE.md` | 206–212 | §4 M4, M9 | yes |
| CL-58 | C6 principle: compression never trades away the durable record | CANONICAL | `clouds/C6/C6-CLOUD-EVALUATION-ENGINE.md` | 304–304 | SC-08 | yes |
| CL-59 | C5 research: checkpoint dependency on C6 | CANONICAL | `clouds/C5/C5-OPERATOR-CONTROL-RESEARCH.md` | 488–490 | §6.2 | yes |
| CL-60 | C5 research P10: resume from structured state; state-only vs audit-preserving open | CANONICAL | `clouds/C5/C5-OPERATOR-CONTROL-RESEARCH.md` | 633–649 | §0.6, §1 | yes |
| CL-61 | C5 P8: unattended mode fails closed; whether unattended exists UNKNOWN | CANONICAL | `clouds/C5/C5-OPERATOR-CONTROL-RESEARCH.md` | 344–371 | SC-13 | yes |
| CL-62 | C5 E5 recovery success; E8 UI/runtime authority mismatch | CANONICAL | `clouds/C5/C5-OPERATOR-CONTROL-RESEARCH.md` | 478–525 | §0.6, SC-06 | yes |
| CL-63 | C5 packs v2 N1: checkpoint owner C1 (and C2), not C6 | CURRENT_SUPPORTING | `capabilities/future/C5/C5-FUTURE-HUMAN-CONTROL-CAPABILITY-PACKS-v2.md` | 48–48 | §6.2 | yes |
| CL-64 | C5 packs v2 Pack 5: blocked on C1/C2; STOP semantics undefined | CURRENT_SUPPORTING | `capabilities/future/C5/C5-FUTURE-HUMAN-CONTROL-CAPABILITY-PACKS-v2.md` | 116–122 | §6.1 | yes |
| CL-65 | C4 packs Q5: checkpoint/resumption ownership gap; C6 has zero checkpoint content | CURRENT_SUPPORTING | `capabilities/future/C4/C4-FUTURE-ENGINEERING-CAPABILITY-PACKS.md` | 60–60 | §6.2 | yes |
| CL-66 | C4 packs Q6: C3 owns isolation interface; no lease primitive | CURRENT_SUPPORTING | `capabilities/future/C4/C4-FUTURE-ENGINEERING-CAPABILITY-PACKS.md` | 61–61 | SC-16 | yes |
| CL-67 | C4 Pack 001 control-plane journal proposal references approval_ref, snapshot_ref | CURRENT_SUPPORTING | `capabilities/future/C4/C4-FUTURE-ENGINEERING-CAPABILITY-PACKS.md` | 96–106 | §0.6 | yes |
| CL-68 | C4 packs U1 checkpoint ownership gap (C3 or C6 for storage); U2 lease primitive undefined | CURRENT_SUPPORTING | `capabilities/future/C4/C4-FUTURE-ENGINEERING-CAPABILITY-PACKS.md` | 322–323 | §6.2, SC-16 | yes |
| CL-69 | C4 protocol Pattern D: one edit = one checkpoint | CANONICAL | `clouds/C4/C4-SURGICAL-ENGINEERING-PROTOCOL.md` | 247–247 | §6 | yes |
| CL-70 | C2 research RP-1 Plan/Act hard capability split (not used beyond reference) | CANONICAL | `clouds/C2/C2-CLOUD-SECURITY-ADAPTER-RESEARCH.md` | 129–129 | §6 | yes |
| CL-71 | C3 future pack CTX-001..004 are C3's own proposals (identical to r3) | CURRENT_SUPPORTING | `capabilities/future/C3/C3-FUTURE-CONTEXT-CAPABILITY-PACKS.md` | 1–385 | §0.3 | yes |

## Claims about absence (verified by search, not by line range)

| ID | Absent item | Search performed | Result |
|---|---|---|---|
| AB-01 | Wave 3.5 Convergence Patch v3 | `grep -rn -i "convergence patch"` over repo `.md/.yaml/.json`; `git ls-tree -r origin/main`; `evidence/MANIFEST.json`, `evidence/source_moves_registry.json` | Citations only (CL-35, CL-36); no file |
| AB-02 | C3 Wave 3.5 v1 knowledge model | tree listing; CL-51/CL-52 | Absent |
| AB-03 | C1 Synthesis v2 | CL-02; tree listing | Absent |
| AB-04 | C6 Future Capability Pack | CL-03; CL-11 | Absent |
| AB-05 | C4 Wave 3.5 context `.md` | CL-04 | Absent (manifest only) |
| AB-06 | `assurance/experiments/` on `main` (no accepted C3 plan) | `git ls-tree -r origin/main` filtered to `assurance/` returns only `assurance/audits/C7-FFA-003.md` | No accepted output |
| AB-07 | C6 checkpoint/resume content | keyword search `checkpoint` in `clouds/C6/…ENGINE.md` | 0 hits |
| AB-08 | `c2-c6(1).TXT` | session upload directory by name and SHA-256 | Not supplied; raw extraction not performed |

## Source conflicts surfaced (not resolved here)

| Topic | Position A | Position B | Rows |
|---|---|---|---|
| Checkpoint owner | C3 P9: C1/C2 | C5 research: C6; C5 packs v2: C1 and C2; C4 packs: C3 or C6 for storage | CL-23, CL-59, CL-63, CL-65, CL-68 |
| Re-fetch trigger | Canonical C3 §4: UNKNOWN | Historical C1 Correction §7: four triggers incl. 15-minute (flagged judgment call) | CL-18, CL-41 |
| Handoff Record producer | C3 Knowledge v2 §3: C1, once per wave | C1 Correction §3: promoted by the specialist Cloud | CL-38, CL-45 |
| Context Packet keys | C1 Correction §2: task_id, cloud_id, projection_*, token_tier, files | C3 Knowledge v2 §2: (task_packet_id, for_cloud, repo_snapshot_id) | CL-37, CL-44 |
| Approval Record fields | C1 Correction §5 | C3 Knowledge v2 §6 | CL-39, CL-48 |
| What a checkpoint holds | C1 Pattern 5: Repository Snapshot only | This plan's proposed context-snapshot pointer | CL-28 |
