# C3 — Unresolved dependencies and unset thresholds (as of 2026-10-15, baseline `71a3fa6d…`)

Nothing here is resolved by the candidate. Register rows are those on `main`; none is edited.

## Dependencies by Cloud
| Cloud | Needed | Register / source | Status |
|---|---|---|---|
| C1 | Cross-Cloud Synthesis v2 | DEP-03, DEP-10, STATUS §4.1 | ABSENT / PENDING |
| C1 | Ratify: checkpoint owner and invalidation rule; whether a checkpoint may reference a context snapshot (C1 L219 limits it to the Repository Snapshot); Context Packet keys; Approval Record fields; Handoff Record producer | OQ-06; map "Source conflicts" | OPEN, `REQUIRES HUMAN DECISION` for owner |
| C1 | Locate Wave 3.5 Convergence Patch v3 (Approval hash-binding §4) | claim CL-35/36, AB-01 | ABSENT |
| C1 | T0–T5 definition; unattended scope; Wave 4 harness exposing observables | C6 L14; C5 P8 | UNKNOWN |
| C2 | Real decision source replacing the policy stub; Approval hard-gate enforcement (RP-13 not assumed) | OQ-01, DEP-09 | `NEEDS EXPERIMENT` |
| C4 | Duplicate-effect / idempotency mechanism; lease primitive; journal adoption | OQ-02, C4 packs U1/U2 | UNKNOWN |
| C5 | Pause/resume flow; unattended scope; state-only vs audit-preserving resume | C5 packs v2 Pack 5; C5 P8/P10 | blocked on C1/C2 |
| C6 | Evaluation-method review of this plan; Future Capability Pack; verification-authority conflict | DEP-06, DEP-07, ACTION-02 | ABSENT / `DESIGNED` |
| C7 | Independent audit of results after execution (FFA-003 does not cover this plan) | ACTION-03 targets Synthesis only | NOT PERFORMED |
| C3 (own) | P15 pre-experiment; frozen fixtures; TS-1…TS-5 baselines | candidate §4.1 | not run |

## Thresholds that remain unset
Freshness window / age-based staleness (SL-14; C1 Correction §7's 15 minutes is a flagged judgment call); isolation trial count N; token budgets and tier ceilings; compression/collapse windows; retry guarantees (fixture values are test data only); label-accuracy and blind-resume accuracy bars; stale-detection bars for every class except C3 E3's own `head`/`origin_head` check; acceptable compaction fallback rate; dev/held-out sizes; realistic session length; cost and latency bars; touch-only and moved-same-hash policies.

## Source-defined zero requirements (the only fixed bars)
Cross-task leakage (C3 E4 / historical C1 Correction §6); `false_completion` and inert-evidence citation counts (C6 metrics, definitional).

## Test status
`TEST SPECIFIED`: 18 cases, 20 scenarios, 15 staleness conditions, 5 threshold-setting experiments. `TEST EXECUTED`: 0. `PASS WITH EVIDENCE`: 0. Benchmarks run: 0.
