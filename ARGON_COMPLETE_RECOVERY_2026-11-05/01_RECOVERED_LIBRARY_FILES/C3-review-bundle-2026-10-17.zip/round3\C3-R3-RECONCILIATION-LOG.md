# C3 — r3 Reconciliation Log (2026-10-15)

| # | Check | Observed outcome |
|---|---|---|
| 1 | `git ls-remote origin refs/heads/main` | `71a3fa6d1fb1eed0e694886263710d4020e10341` (unchanged since baseline) |
| 2 | `git fetch` main and intake branch; `git merge-base --is-ancestor` | intake tip `37bfc61d…` (PR #1 head) **is an ancestor of main** |
| 3 | Files under `assurance/` on main | only `assurance/audits/C7-FFA-003.md`; **no `assurance/experiments/`** ⇒ no accepted C3 plan |
| 4 | Newer C7 report | none; ACTION-03 plans FFA-004 for the Synthesis, not written |
| 5 | Automated anchor check of 71 claim rows | 71/71 verified after correcting 4 off-by-range entries (CL-04, CL-12, CL-38, CL-71) |
| 6 | Local clone status | clean; no writes to the repository |

## Defects found in r2 and fixed in r3
1. **Historical sources presented as current design.** Staleness triggers, isolation default and Packet fields come from `archive/historical/wave3.5/`; canonical C3 §4 says the re-fetch trigger is UNKNOWN. r3 labels them (H) and treats them as proposals.
2. **No separation of artifact standing** (canonical / supporting / historical / absent / staging / accepted). r3 §0.3 adds it.
3. **No explicit scenarios.** r3 §3.0 adds 19; adds SC-17 (label preservation) and SC-18 (cannot-fit safe failure).
4. **No executed-vs-specified ledger.** r3 §7.3 adds it with counts.
5. **No exact source ranges.** `maps/C3-SOURCE-TO-CLAIM-MAP.md` adds 71 machine-checked rows plus absence and conflict tables.

## Still true from earlier passes
TXT `c2-c6(1).TXT` not supplied; raw extraction of lines 567–968 not performed; prior draft not proven equal to it.
