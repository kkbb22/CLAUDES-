# Raw extraction — provenance note (C3, TXT lines 567–968)

**Status: RAW EXTRACTION NOT PERFORMED. BLOCKER, not a guess.**

| Item | Value |
|---|---|
| Source container named by the pack | `c2-c6(1).TXT`, 2,240 lines / 221,902 bytes |
| Expected SHA-256 (from the pack) | `a542be977e7af20dfe90be08585b1a05e094351805a0d8c9dcb22301b2d0039a` |
| Assigned line range | 567–968 |
| File supplied to this session | **No.** Only `ARGON_CLOUDS_1-7_PARALLEL_PROMPT_PACK_2026-10-14.md` (SHA-256 `12b8a45a32602429bb9b23b5bbfaacc3096a6c1c1aee9ed2b93191c592473ab5`) was uploaded. A search of the session's upload directory found no file with that name or hash. |
| Raw copy in staging | **None.** No placeholder or reconstruction was written into `raw/`. |

## What stands in for it, and what that does not prove

`prior-draft/C3-CONTEXT-ISOLATION-AND-RESUMPTION-PLAN.prior-draft-2026-10-13.md` is my own earlier draft (the C3 plan delivered 2026-10-13). It is the diff baseline for this candidate. **It is not proven to equal TXT lines 567–968.** Its hash is in the manifest. No claim is made that the TXT range matches it, or that any Markdown hash equals the TXT hash.

## How the holder of the TXT can complete this step (byte-preserving, no newline normalization)

```bash
sha256sum "c2-c6(1).TXT"        # must print a542be977e7af20dfe90be08585b1a05e094351805a0d8c9dcb22301b2d0039a
sed -n '567,968p' "c2-c6(1).TXT" > raw/C3-RAW-EXTRACT-TXT-L567-L968.bin.md
sha256sum raw/C3-RAW-EXTRACT-TXT-L567-L968.bin.md
diff raw/C3-RAW-EXTRACT-TXT-L567-L968.bin.md prior-draft/C3-CONTEXT-ISOLATION-AND-RESUMPTION-PLAN.prior-draft-2026-10-13.md
```

(`sed -n` preserves bytes except that it adds a trailing newline if the last line lacked one; on Windows use `Get-Content -Raw` ranges or a byte-offset tool if CRLF must be preserved. Record whichever method is used.)

If the range differs from the prior draft, the TXT range governs as the raw source and the corrections in the candidate must be re-checked against it.
