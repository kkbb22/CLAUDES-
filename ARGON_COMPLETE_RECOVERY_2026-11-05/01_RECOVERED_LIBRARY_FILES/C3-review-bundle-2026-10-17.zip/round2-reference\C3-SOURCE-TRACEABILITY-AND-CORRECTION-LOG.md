# C3 — Source Traceability and Correction Log

Candidate: `candidate/assurance/experiments/C3-CONTEXT-ISOLATION-AND-RESUMPTION-PLAN.md` (SHA-256 in the manifest).
Baseline repo: AI-OS `main` `71a3fa6d1fb1eed0e694886263710d4020e10341`. Compared against the 2026-10-13 prior draft (my own; **not** proven equal to TXT lines 567–968, which was not supplied).

## A. Corrected claims

| # | Prior-draft statement | Finding on `main` | Evidence | Candidate fix |
|---|---|---|---|---|
| A1 | C1 artifacts "NOT AVAILABLE" | `clouds/C1/C1-CLOUD-HARNESS-ADAPTER-RESEARCH.md` exists, hash `24e8cdb1…688f` = `STATUS.md` §3 | repo tree + `sha256sum` | §0.3; C1 content used (Pattern 5, Kernel items). **C1 Cross-Cloud Synthesis v2 is genuinely absent** (STATUS, DEP-03) and stays so |
| A2 | C5 pack v2 "NOT AVAILABLE" | `capabilities/future/C5/…PACKS-v2.md` + manifest exist; hash `744a1c62…bff0` equals its `report_sha256` | `sha256sum` | §0.3, §6.2 (N1) |
| A3 | C2 / C4 packs not referenced | Both exist | repo tree | §0.3 |
| A4 | `OPEN-QUESTIONS.md` not available | Exists; **OQ-06** covers this plan's subject | read in full | §0.5 |
| A5 | `DEPENDENCY-REGISTER.md` not available | Exists; no row for this plan | read in full | §0.5, §6.1, proposals file |
| A6 | `NEXT-ACTIONS.md` (not mentioned as present) | Exists; no C3 action | read in full | §0.3 |
| A7 | "Wave 3.5 schemas NOT AVAILABLE"; field names unverified | Context Projection/Packet, Repository Snapshot, evidence chain, Approval, isolation default, staleness triggers **are defined** in `archive/historical/wave3.5/` | grep + read | §0.4 table "Found" |
| A8 | C3 future pack "cannot confirm byte-identical" | Byte-identical (`bb0568be…83cf`) | `sha256sum` | §0.3 |
| A9 | (new error found while correcting) Plan used "handoff record" | `Handoff Record` is a reserved Wave 3.5 object name | C3 Knowledge v2 §3 | Renamed "resumption record" everywhere |
| A10 | (new) Checkpoint = a pointer to a context snapshot | C1 L219 defines checkpointed state as the Repository Snapshot, **not** conversational context | C1 research | §1 divergence note; §5 open decision |
| A11 | Checkpoint ownership: two sources | **Five** source positions (C3 P9; C1; C5 research; C5 packs v2 N1; C4 packs U1) | §6.2 | Listed all; none chosen |

## B. Evidence found vs not found

**Found:** items in A1–A8; Wave 3.5 definitions listed in plan §0.4; C1 Correction §6 isolation default, §7 triggers; C3 Knowledge v2 §5 evidence rule; C1 research Pattern 5 six questions.

**Not found (searched):**

| Item | Search | Result |
|---|---|---|
| Wave 3.5 **Convergence Patch v3** | `grep -rn -i "convergence patch"` over repo `.md/.yaml/.json`; tree listing; `evidence/MANIFEST.json`, `evidence/source_moves_registry.json` | Only citations inside C1 research (L202, L223, L355–361, L517). **No file.** True missing patch |
| `C3-WAVE3.5-AI-OS-KNOWLEDGE-MODEL.md` (v1) | tree listing; v2 header/§9 | Absent; v2 §9 defers unchanged object definitions to it |
| C4 Wave 3.5 context `.md` | `STATUS.md` §4.3; tree | Manifest only |
| C6 future pack | `capability-index.md`, DEP-07 | Absent |
| C1 Synthesis v2 | `STATUS.md`, `CURRENT-STATE.md` | Absent |
| Checkpoint-reference Approval field; checkpoint invalidation; resumption mechanism | C1 L221–L224, L495; OQ-06 | Undesigned |
| `c2-c6(1).TXT` | session upload dir by name and by SHA-256 | Not supplied |

## C. Material changes by plan section

| Section | Change | Reason / source |
|---|---|---|
| Header | Date, `test_status`, TXT SHA + range, `raw_extraction: NOT_PERFORMED`, hash contract line | Pack shared rules |
| §0 | Rewritten (provenance, baseline, inventory, schema search, registers) | A1–A8 |
| §1 | `resumption record` rename; checkpoint divergence; name-clash warnings | A9, A10 |
| §2 | + FX-EVIDENCE-1; + §2.2 controlled staleness (SL-01…SL-15); + §2.3 independent oracles O1–O8 | Pack item 5 |
| §3 | Oracle + status lines per case; SC-01 cites C1 §6 default; new Group E (SC-14 evidence chain, SC-15 Projection version, SC-16 concurrent resumption) | Pack item 5 |
| §4 | `NOT YET SET` → `NOT SET`; + M9, M10 | Vocabulary; new cases |
| §5 | Expanded; checkpoint ownership marked `REQUIRES HUMAN DECISION` | Pack item 6 |
| §6 | Updated matrix; §6.1 exact per-Cloud dependencies; §6.2 checkpoint sources | Pack items 2, 4, final report |
| §7 | + §7.3 result statuses; + §7.4 regression-retention | Pack item 5 |
| §8–9 | Updated unknowns and change summary | — |

## D. Values deliberately NOT adopted or set

C1 Correction §7's **15-minute** snapshot-age figure (its author flags it as a judgment call needing human confirmation); any freshness window; token budgets; T0–T5 ceilings; compression windows; retry guarantees (the fixture's "3" and "5" are test data, not recommendations); leakage counts above zero; trial count N; dev/held-out split sizes; session length (P15); acceptable fallback rates; any checkpoint owner.

## E. Validation commands run and observed outcomes

| Command | Outcome |
|---|---|
| `git ls-remote origin refs/heads/main` | `71a3fa6d1fb1eed0e694886263710d4020e10341` |
| `git rev-parse --abbrev-ref HEAD`, `git log -1 --format=%H`, `git status --short` (clone) | `main`, `71a3fa6d…`, clean |
| `sha256sum` over 22 inspected repo files | `logs/input-hashes.txt`; C1–C6 hashes match `STATUS.md` §3; C3 pack = my r3; C5 v2 = its `report_sha256` |
| `grep -rn -i "convergence patch"` | citations only, no file |
| Hash scan of session uploads for `a542be97…` | 0 matches |
| Final-byte `sha256sum` of candidate | in manifest |

## F. Read-extent disclosure

Whole-file reads: the five registers, the C3 research, C2/C4/C5/C6 research (earlier in this task, hash-identical to repo), C7 audit (earlier + re-read of Gates 3, 4, 9). **Section and keyword reads only** (not whole-file): C1 research, C2/C4/C5 future packs, Wave 3.5 C1/C3/C5/C6 files. Claims drawn from those are cited to the sections read.
