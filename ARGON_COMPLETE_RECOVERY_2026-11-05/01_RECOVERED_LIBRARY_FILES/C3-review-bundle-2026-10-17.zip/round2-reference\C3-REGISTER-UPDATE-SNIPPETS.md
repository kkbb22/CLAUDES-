# Proposed register snippets (text only, for the integration owner)

**Not applied.** No shared register, `STATUS.md`, `capability-index.md` or canonical file was edited. These are proposals.

## OPEN-QUESTIONS (new rows; OQ-06 already exists)
- **Checkpoint object ownership.** Sources disagree: C3 P9 (C1/C2), C1 research (Kernel rule + Runtime mechanism), C5 research (C6), C5 packs v2 N1 (C1 and C2), C4 packs U1 (C3 or C6 for storage). Status `REQUIRES HUMAN DECISION` / C1 Synthesis.
- May a checkpoint reference point to a **context snapshot**, given C1 research L219 limits the checkpoint to the Repository Snapshot at approval?
- Reconcile Context Packet field names (C1 Correction §2 vs C3 Knowledge v2 §2), Approval Record fields (C3 v2 §6 vs C1 §5) and the Handoff Record producer (C3 v2 §3 vs C1 §3).
- Location of **Wave 3.5 Convergence Patch v3** (cited by C1 research; not in the repository).
- Freshness window / age-based staleness: C1 Correction §7's 15 minutes is a flagged judgment call. `THRESHOLD NOT SET`.
- Touch-only and moved-same-hash policy for stale detection (`OPEN`).

## DEPENDENCY-REGISTER (new row)
`DEP-xx | C1, C2, C4, C5, C6 | C3 | Prerequisites for context-isolation and stale-state-resumption experiments: Wave 4 harness exposing the observables; C2 decision source; C4 idempotency/lease; C5 resume flow; C6 evaluation method; reconciled Wave 3.5 schemas; ratified tier scheme; P15 result | candidate plan §6.1 | UNRESOLVED, TEST SPECIFIED`

## NEXT-ACTIONS (suggestion)
After ACTION-01 (C1 Synthesis v2), C1 to decide checkpoint ownership and the schema reconciliations above; C6 to review the C3 plan's method (§2.3, §7.4) as part of authoring its Future Capability Pack (ACTION-02).
