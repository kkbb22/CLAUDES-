ARGON C1 STARTER PACK

Contains:
1) ARGON_MASTER_HANDOVER_2026-11-04.zip
2) ARGON_CLOUD_DISPATCH_PACK_2026-11-04.md

Purpose: Provide C1 with the consolidated project handover and the original seven-cloud dispatch instructions.

Important: These are reference/source-asserted handover materials. They do not replace missing original candidate packages, repository evidence, or the PR-09 local branch export.
